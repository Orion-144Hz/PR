# tests/test_solvers.py
import pytest
import requests
import json
import time
import base64
from PIL import Image
import io
import numpy as np
from unittest.mock import Mock, patch
import tempfile
import os

import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.core.captcha_solver import HybridCaptchaSolver, AdvancedHybridCaptchaSolver, CaptchaResult, CaptchaType

class TestCaptchaSolver:
    """CAPTCHA çözücü test sınıfı"""
    
    def setup_method(self):
        """Test setup"""
        self.solver = HybridCaptchaSolver()
    
    def teardown_method(self):
        """Test cleanup"""
        if self.solver:
            # Temizlik işlemleri
            pass
    
    def test_text_captcha_solution(self):
        """Metin CAPTCHA çözüm testi"""
        # Test görüntüsü oluştur
        test_image = self._create_test_text_image("TEST123")
        
        # Çözüm yap
        result = self.solver.solve_captcha(test_image)
        
        # Sonuçları kontrol et
        assert result.success
        assert result.captcha_type.value == "text_based"
        assert result.solver_used == "OCR"
        assert result.processing_time > 0
    
    def test_image_selection_captcha_solution(self):
        """Görüntü seçimi CAPTCHA çözüm testi"""
        # Test görüntüsü oluştur
        test_image = self._create_test_grid_image()
        
        # Çözüm yap
        result = self.solver.solve_captcha(test_image)
        
        # Sonuçları kontrol et
        assert result.success
        assert result.captcha_type.value == "image_selection"
        assert result.solver_used in ["YOLO", "Advanced_YOLO"]
        assert result.processing_time > 0
    
    def test_captcha_type_detection(self):
        """CAPTCHA türü tespiti testi"""
        # Metin CAPTCHA
        text_image = self._create_test_text_image("ABC123")
        text_type = self.solver.type_detector.detect_type(text_image)
        assert text_type.value == "text_based"
        
        # Grid CAPTCHA
        grid_image = self._create_test_grid_image()
        grid_type = self.solver.type_detector.detect_type(grid_image)
        assert grid_type.value == "image_selection"
    
    def test_cache_functionality(self):
        """Cache fonksiyonelliği testi"""
        # Test görüntüsü oluştur
        test_image = self._create_test_text_image("CACHE123")
        
        # İlk çözüm
        result1 = self.solver.solve_captcha(test_image, use_cache=True)
        
        # İkinci çözüm (cache'den gelmeli)
        result2 = self.solver.solve_captcha(test_image, use_cache=True)
        
        # Cache istatistiklerini kontrol et
        cache_stats = self.solver.get_cache_stats()
        assert cache_stats['cache_hits'] > 0
        assert cache_stats['hit_rate'] > 0
        
        # Sonuçların aynı olduğunu kontrol et
        assert result1.result == result2.result
    
    def test_performance_monitoring(self):
        """Performans monitör testi"""
        # Birkaç çözüm yap
        for i in range(5):
            test_image = self._create_test_text_image(f"PERF{i:03d}")
            self.solver.solve_captcha(test_image)
        
        # Performans metriklerini kontrol et
        metrics = self.solver.get_performance_metrics()
        assert metrics['total_requests'] >= 5
        assert metrics['average_processing_time'] > 0
        
        # Detaylı performans raporu
        detailed_perf = self.solver.get_detailed_performance()
        assert 'base_metrics' in detailed_perf
        assert 'cache_stats' in detailed_perf
    
    def _create_test_text_image(self, text: str) -> np.ndarray:
        """Test metin görüntüsü oluştur"""
        # Basit bir metin görüntüsü oluştur
        image = Image.new('RGB', (200, 50), color='white')
        from PIL import ImageDraw, ImageFont
        
        draw = ImageDraw.Draw(image)
        try:
            font = ImageFont.truetype("arial.ttf", 20)
        except:
            font = ImageFont.load_default()
        
        draw.text((10, 15), text, fill='black', font=font)
        
        return np.array(image)
    
    def _create_test_grid_image(self) -> np.ndarray:
        """Test grid görüntüsü oluştur"""
        # 3x3 grid oluştur
        image = Image.new('RGB', (300, 300), color='lightgray')
        draw = ImageDraw.Draw(image)
        
        # Grid çizgileri
        for i in range(4):
            # Dikey çizgiler
            draw.line([(i * 100, 0), (i * 100, 300)], fill='black', width=2)
            # Yatay çizgiler
            draw.line([(0, i * 100), (300, i * 100)], fill='black', width=2)
        
        # Rastgele nesneler ekle
        draw.ellipse([20, 20, 80, 80], fill='red')  # Kırmızı daire
        draw.rectangle([120, 120, 180, 180], fill='blue')  # Mavi kare
        
        return np.array(image)

class TestAdvancedCaptchaSolver:
    """Gelişmiş CAPTCHA çözücü test sınıfı"""
    
    def setup_method(self):
        """Test setup"""
        self.solver = AdvancedHybridCaptchaSolver()
        self.solver.start_advanced_features()
    
    def teardown_method(self):
        """Test cleanup"""
        if self.solver:
            self.solver.stop_advanced_features()
    
    def test_continuous_learning(self):
        """Sürekli öğrenme testi"""
        # Test görüntüsü oluştur
        test_image = self._create_test_text_image("LEARN123")
        
        # Çözüm yap
        result = self.solver.solve_captcha(test_image)
        
        # Kullanıcı geri bildirimi ekle
        self.solver.add_user_feedback(
            test_image,
            result.result,
            "CORRECT",  # Gerçek sonuç
            result.confidence
        )
        
        # Geri bildirim işlendi mi kontrol et
        assert self.solver.continuous_learning is not None
    
    def test_performance_monitoring(self):
        """Performans monitör testi"""
        # Birkaç çözüm yap
        for i in range(5):
            test_image = self._create_test_text_image(f"MONITOR{i:03d}")
            self.solver.solve_captcha(test_image)
        
        # Performans metriklerini kontrol et
        metrics = self.solver.get_performance_metrics()
        assert metrics['total_requests'] >= 5
        assert metrics['average_processing_time'] > 0
        
        # Detaylı performans raporu
        detailed_perf = self.solver.get_detailed_performance()
        assert 'base_metrics' in detailed_perf
        assert 'cache_stats' in detailed_perf
        assert 'recent_alerts' in detailed_perf
        assert 'system_status' in detailed_perf
    
    def _create_test_text_image(self, text: str) -> np.ndarray:
        """Test metin görüntüsü oluştur"""
        # Basit bir metin görüntüsü oluştur
        image = Image.new('RGB', (200, 50), color='white')
        from PIL import ImageDraw, ImageFont
        
        draw = ImageDraw.Draw(image)
        try:
            font = ImageFont.truetype("arial.ttf", 20)
        except:
            font = ImageFont.load_default()
        
        draw.text((10, 15), text, fill='black', font=font)
        
        return np.array(image)

class TestAPIEndpoints:
    """API endpoint test sınıfı"""
    
    def setup_method(self):
        """Test setup"""
        # Test için geçici config oluştur
        self.temp_dir = tempfile.mkdtemp()
        self.config_path = os.path.join(self.temp_dir, "test_config.json")
        
        test_config = {
            "redis": {"host": "localhost", "port": 6379, "db": 0},
            "solvers": {
                "ocr": {"enabled": True, "model_path": None},
                "yolo": {"enabled": True, "model_path": None}
            }
        }
        
        with open(self.config_path, 'w') as f:
            json.dump(test_config, f)
        
        # Test solver'ı başlat
        from src.api.server import ProductionCaptchaSolver
        self.solver = ProductionCaptchaSolver(self.config_path)
    
    def teardown_method(self):
        """Test cleanup"""
        import asyncio
        if self.solver:
            asyncio.run(self.solver.cleanup())
        
        # Temp dosyaları temizle
        import shutil
        shutil.rmtree(self.temp_dir)
    
    def test_api_solve_endpoint(self):
        """API solve endpoint testi"""
        # Test görüntüsü oluştur
        test_image = self._create_test_image()
        image_base64 = base64.b64encode(test_image).decode()
        
        # API isteği yap
        response = requests.post(
            "http://localhost:8000/solve",
            json={
                "image_data": image_base64,
                "use_cache": True
            }
        )
        
        # Sonucu kontrol et
        assert response.status_code == 200
        data = response.json()
        assert data['success']
        assert 'result' in data
        assert data['processing_time'] > 0
    
    def test_api_health_endpoint(self):
        """API health endpoint testi"""
        response = requests.get("http://localhost:8000/health")
        
        assert response.status_code == 200
        data = response.json()
        assert 'status' in data
        assert 'components' in data
        assert 'metrics' in data
    
    def test_api_metrics_endpoint(self):
        """API metrics endpoint testi"""
        response = requests.get("http://localhost:8000/metrics")
        
        assert response.status_code == 200
        assert 'captcha_requests_total' in response.text
    
    def _create_test_image(self) -> bytes:
        """Test görüntüsü oluştur"""
        image = Image.new('RGB', (200, 50), color='white')
        draw = ImageDraw.Draw(image)
        draw.text((10, 15), "TEST", fill='black')
        
        img_byte_arr = io.BytesIO()
        image.save(img_byte_arr, format='PNG')
        return img_byte_arr.getvalue()

# Kullanım örnekleri
def usage_examples():
    """Kullanım örnekleri"""
    
    print("🚀 Hibrit CAPTCHA Çözüm Sistemi Kullanım Örnekleri")
    print("=" * 60)
    
    # 1. Temel kullanım
    print("\n1. Temel Kullanım:")
    print("-" * 30)
    
    solver = HybridCaptchaSolver()
    
    # Metin CAPTCHA çözümü
    text_captcha = "text_captcha_image.png"
    result = solver.solve_captcha(text_captcha)
    print(f"Metin CAPTCHA Sonucu: {result.result}")
    print(f"Başarı: {result.success}")
    print(f"İşlem Süresi: {result.processing_time:.3f}s")
    
    # 2. Gelişmiş kullanım
    print("\n2. Gelişmiş Kullanım:")
    print("-" * 30)
    
    advanced_solver = AdvancedHybridCaptchaSolver()
    advanced_solver.start_advanced_features()
    
    # Görüntü seçimi CAPTCHA çözümü
    image_selection_captcha = "grid_captcha_image.png"
    result = advanced_solver.solve_captcha(image_selection_captcha)
    print(f"Grid CAPTCHA Sonucu: {result.result}")
    print(f"Kullanılan Çözücü: {result.solver_used}")
    
    # Kullanıcı geri bildirimi ekle
    advanced_solver.add_user_feedback(
        image_selection_captcha,
        result.result,
        "CORRECT",  # Gerçek sonuç
        result.confidence
    )
    
    # Performans raporu
    perf_report = advanced_solver.get_detailed_performance()
    print(f"Cache Hit Rate: {perf_report['cache_stats']['hit_rate']:.3f}")
    
    advanced_solver.stop_advanced_features()
    
    # 3. API kullanımı
    print("\n3. API Kullanımı:")
    print("-" * 30)
    
    # API ile CAPTCHA çözümü
    import requests
    
    # Görüntüyü base64'e çevir
    with open("test_captcha.png", "rb") as f:
        image_data = base64.b64encode(f.read()).decode()
    
    # API isteği
    response = requests.post(
        "http://localhost:8000/solve",
        json={
            "image_data": image_data,
            "use_cache": True
        }
    )
    
    if response.status_code == 200:
        data = response.json()
        print(f"API Sonucu: {data['result']}")
        print(f"Başarı: {data['success']}")
    else:
        print(f"API Hatası: {response.status_code}")
    
    # 4. Batch processing
    print("\n4. Batch Processing:")
    print("-" * 30)
    
    def process_batch_captchas(captcha_files):
        """Birden fazla CAPTCHA'yı çöz"""
        results = []
        
        for file_path in captcha_files:
            try:
                result = solver.solve_captcha(file_path)
                results.append({
                    'file': file_path,
                    'success': result.success,
                    'result': result.result,
                    'processing_time': result.processing_time
                })
            except Exception as e:
                results.append({
                    'file': file_path,
                    'success': False,
                    'error': str(e)
                })
        
        return results
    
    # Örnek batch işlemi
    captcha_files = ["captcha1.png", "captcha2.png", "captcha3.png"]
    batch_results = process_batch_captchas(captcha_files)
    
    for result in batch_results:
        print(f"{result['file']}: {'✓' if result['success'] else '✗'}")
        if result['success']:
            print(f"  Sonuç: {result['result']}")
            print(f"  Süre: {result['processing_time']:.3f}s")
        else:
            print(f"  Hata: {result.get('error', 'Unknown error')}")
    
    # 5. Monitoring ve alerting
    print("\n5. Monitoring ve Alerting:")
    print("-" * 30)
    
    # Sağlık kontrolü
    health = solver.get_solver_status()
    print("Solver Durumları:")
    for name, status in health.items():
        print(f"  {name}: {'✓' if status['available'] else '✗'}")
    
    # Performans metrikleri
    metrics = solver.get_performance_metrics()
    print(f"\nToplam İstek: {metrics['total_requests']}")
    print(f"Başarılı Çözüm: {metrics['successful_solves']}")
    print(f"Başarısız Çözüm: {metrics['failed_solves']}")
    print(f"Ortalama Süre: {metrics['average_processing_time']:.3f}s")
    
    # 6. Custom solver ekleme
    print("\n6. Custom Solver Ekleme:")
    print("-" * 30)
    
    class CustomMathSolver:
        """Matematik CAPTCHA çözücü"""
        
        def can_solve(self, captcha_type: CaptchaType) -> bool:
            return captcha_type == CaptchaType.MATH_CHALLENGE
        
        def solve(self, captcha_data: Union[str, np.ndarray, bytes]) -> CaptchaResult:
            start_time = time.time()
            
            try:
                # Matematik ifadesini çöz
                if isinstance(captcha_data, str):
                    expression = captcha_data
                    # Basit matematik ifadesi çözümü
                    result = eval(expression)
                    
                    return CaptchaResult(
                        success=True,
                        result=str(result),
                        confidence=1.0,
                        processing_time=time.time() - start_time,
                        captcha_type=CaptchaType.MATH_CHALLENGE,
                        solver_used="MathSolver"
                    )
                
            except Exception as e:
                return CaptchaResult(
                    success=False,
                    result="",
                    confidence=0.0,
                    processing_time=time.time() - start_time,
                    captcha_type=CaptchaType.MATH_CHALLENGE,
                    solver_used="MathSolver",
                    error_message=str(e)
                )
    
    # Custom solver'ı ekle
    solver.solvers['math'] = CustomMathSolver()
    
    # Matematik CAPTCHA'sını çöz
    math_result = solver.solve_captcha("5 + 3")
    print(f"Matematik CAPTCHA Sonucu: {math_result.result}")
    
    print("\n✅ Kullanım örnekleri tamamlandı")

if __name__ == "__main__":
    # Testleri çalıştır
    print("🧪 Testler Başlatılıyor...")
    
    # Basit testler
    test_solver = TestCaptchaSolver()
    try:
        test_solver.setup_method()
        test_solver.test_text_captcha_solution()
        test_solver.test_image_selection_captcha_solution()
        test_solver.test_captcha_type_detection()
        test_solver.test_cache_functionality()
        test_solver.test_performance_monitoring()
        print("✅ Temel testler başarılı")
    finally:
        test_solver.teardown_method()
    
    # Gelişmiş testler
    advanced_test_solver = TestAdvancedCaptchaSolver()
    try:
        advanced_test_solver.setup_method()
        advanced_test_solver.test_continuous_learning()
        advanced_test_solver.test_performance_monitoring()
        print("✅ Gelişmiş testler başarılı")
    finally:
        advanced_test_solver.teardown_method()
    
    # Kullanım örneklerini göster
    usage_examples()
    
    print("\n🎉 Tüm testler ve örnekler tamamlandı!")
