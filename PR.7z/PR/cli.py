# cli.py
#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import json
import argparse
import logging
import asyncio
import threading
import time
import signal
import subprocess
from typing import Dict, List, Optional, Union, Any
from dataclasses import dataclass, asdict
from enum import Enum
import cmd
import readline
import glob
import importlib
import pkg_resources
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('cli_system.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class SystemMode(Enum):
    CLI = "cli"
    GUI = "gui"
    API = "api"
    BATCH = "batch"

@dataclass
class SystemConfig:
    mode: SystemMode = SystemMode.CLI
    config_path: Optional[str] = None
    log_level: str = "INFO"
    max_workers: int = 4
    enable_lazy_loading: bool = True
    enable_rate_limiting: bool = True
    enable_monitoring: bool = True
    api_port: int = 8000
    api_host: str = "0.0.0.0"
    
    def to_dict(self) -> Dict:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'SystemConfig':
        return cls(**data)

class CaptchaShell(cmd.Cmd):
    
    intro = "Yardım için 'help' veya '?' yazın, çıkmak için 'exit' veya 'quit' yazın\n"
    prompt = "(captcha) "
    file = None
    
    def __init__(self, config: SystemConfig):
        super().__init__()
        self.config = config
        self.solver = None
        self.model_loader = None
        self.rate_limiter = None
        self.metrics_collector = None
        self.accessibility_manager = None
        self.executor = None
        self.running = True
        
        self._initialize_system()
        
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
    
    def _signal_handler(self, signum, frame):
        print("\nKapatılıyor...")
        self.running = False
        self.close()
    
    def _initialize_system(self):
        try:
            logger.info("Hibrit CAPTCHA Çözüm Sistemi başlatılıyor...")
            
            self._load_modules()
            
            if self.config.mode == SystemMode.API:
                from src.api.server import ProductionCaptchaSolver
                self.solver = ProductionCaptchaSolver(self.config.config_path)
            else:
                from src.core.captcha_solver import AdvancedHybridCaptchaSolver
                self.solver = AdvancedHybridCaptchaSolver(self.config.config_path)
            
            if hasattr(self.solver, 'start_advanced_features') and self.config.enable_monitoring:
                self.solver.start_advanced_features()
            
            logger.info("Sistem başarıyla başlatıldı")
            
        except Exception as e:
            logger.error(f"Sistem başlatılamadı: {e}")
            raise
    
    def _load_modules(self):
        try:
            from src.core.browser_utils import BrowserUtils
            from src.core.email_utils import EmailUtils
            from src.core.utils import Utils
            from src.core.monitoring import Monitoring
            
            from src.platforms.tiktok import TikTokPlatform
            from src.platforms.instagram import InstagramPlatform
            from src.platforms.twitter import TwitterPlatform
            from src.platforms.facebook import FacebookPlatform
            
            from src.api.server import ProductionCaptchaSolver
            
            logger.info("Tüm modüller başarıyla yüklendi")
            
        except ImportError as e:
            logger.error(f"Modüller yüklenemedi: {e}")
            print(f"Hata: {e}. Lütfen tüm bağımlılıkların yüklendiğinden emin olun.")
            sys.exit(1)
    
    def do_solve(self, arg):
        """Tekil CAPTCHA çözümü: solve <dosya_yolu>"""
        if not arg:
            print("Hata: Dosya yolu belirtilmedi")
            return
        
        file_path = arg.strip()
        if not os.path.exists(file_path):
            print(f"Hata: Dosya bulunamadı: {file_path}")
            return
        
        try:
            print(f"Çözülüyor: {file_path}")
            result = self.solver.solve_captcha(file_path)
            
            print(f"\nSonuçlar:")
            print(f"Başarı: {'✓' if result.success else '✗'}")
            print(f"Çözüm: {result.result}")
            print(f"Güven: {result.confidence:.3f}")
            print(f"İşlem Süresi: {result.processing_time:.3f}s")
            print(f"Kullanılan Çözücü: {result.solver_used}")
            print(f"CAPTCHA Türü: {result.captcha_type.value}")
            
            if result.error_message:
                print(f"Hata: {result.error_message}")
                
        except Exception as e:
            print(f"Çözüm başarısız: {e}")
    
    def do_batch(self, arg):
        """Batch CAPTCHA çözümü: batch <dizin_yolu>"""
        if not arg:
            print("Hata: Dizin yolu belirtilmedi")
            return
        
        directory = arg.strip()
        if not os.path.isdir(directory):
            print(f"Hata: Dizin bulunamadı: {directory}")
            return
        
        # Dosyaları listele
        image_files = []
        for ext in ['*.png', '*.jpg', '*.jpeg', '*.gif', '*.bmp']:
            image_files.extend(glob.glob(os.path.join(directory, ext)))
        
        if not image_files:
            print("Dizinde görüntü dosyası bulunamadı!")
            return
        
        print(f"\n{len(image_files)} dosya bulundu")
        
        results = []
        for i, file_path in enumerate(image_files, 1):
            print(f"\n[{i}/{len(image_files)}] İşleniyor: {os.path.basename(file_path)}")
            
            try:
                result = self.solver.solve_captcha(file_path)
                results.append({
                    'file': file_path,
                    'success': result.success,
                    'result': result.result,
                    'processing_time': result.processing_time
                })
                
                status = "✓" if result.success else "✗"
                print(f"Durum: {status} | Sonuç: {result.result} | Süre: {result.processing_time:.3f}s")
                
            except Exception as e:
                results.append({
                    'file': file_path,
                    'success': False,
                    'error': str(e)
                })
                print(f"Hata: {e}")
        
        successful = sum(1 for r in results if r['success'])
        print(f"\nÖzet: {successful}/{len(results)} başarılı")
        
        save_report = input("Rapor kaydedilsin mi? (e/h): ").strip().lower()
        if save_report == 'e':
            report_path = os.path.join(directory, "batch_report.json")
            with open(report_path, 'w') as f:
                json.dump(results, f, indent=2)
            print(f"Rapor kaydedildi: {report_path}")
    
    def do_status(self, arg):
        print("\n--- Sistem Durumu ---")
        
        try:
            status = self.solver.get_system_status() if hasattr(self.solver, 'get_system_status') else {}
            
            print(f"Çalışma Modu: {self.config.mode.value}")
            
            if 'loaded_models' in status:
                print(f"Yüklenmiş Modeller: {', '.join(status['loaded_models'])}")
            
            if 'memory_usage' in status:
                print("\nHafıza Kullanımı:")
                for model, usage in status['memory_usage'].items():
                    print(f"  {model}: {usage / (1024*1024):.2f} MB")
            
            if 'business_metrics' in status:
                print("\nİş Metrikleri:")
                metrics = status['business_metrics']
                if 'success_rate_trend' in metrics:
                    print(f"  Başarı Oranı: {metrics['success_rate_trend'].get('rate', 0):.3f}")
                
                if 'solver_comparison' in metrics:
                    print("\nSolver Karşılaştırması:")
                    for solver, comp in metrics['solver_comparison'].items():
                        print(f"  {solver}: {comp.get('success_rate', 0):.3f} başarı, {comp.get('avg_processing_time', 0):.3f}s")
                
                if 'error_analysis' in metrics and metrics['error_analysis']:
                    print("\nYaygın Hatalar:")
                    for error, count in list(metrics['error_analysis'].items())[:3]:
                        print(f"  {error}: {count} kez")
            
            if hasattr(self.solver, 'get_solver_status'):
                solver_status = self.solver.get_solver_status()
                print("\nSolver Durumları:")
                for name, info in solver_status.items():
                    print(f"  {name}: {'✓' if info.get('available', False) else '✗'}")
            
            if hasattr(self.solver, 'get_performance_metrics'):
                perf_metrics = self.solver.get_performance_metrics()
                print("\nPerformans Metrikleri:")
                for key, value in perf_metrics.items():
                    print(f"  {key}: {value}")
            
        except Exception as e:
            print(f"Durum bilgisi alınamadı: {e}")
    
    def do_train(self, arg):
        """Model eğitimi: train [captcha|yolo]"""
        args = arg.split()
        if not args:
            print("Hata: Model türü belirtilmedi")
            return
        
        model_type = args[0].lower()
        
        if model_type == "captcha":
            print("CRNN CAPTCHA modeli eğitiliyor...")
            try:
                from src.training.captcha_trainer import main as train_captcha
                train_captcha()
                print("Model eğitimi tamamlandı")
            except Exception as e:
                print(f"Eğitim başarısız: {e}")
        
        elif model_type == "yolo":
            print("YOLO modeli eğitiliyor...")
            try:
                from src.training.yolo_trainer import main as train_yolo
                train_yolo()
                print("Model eğitimi tamamlandı")
            except Exception as e:
                print(f"Eğitim başarısız: {e}")
        
        else:
            print(f"Hata: Bilinmeyen model türü: {model_type}")
    
    def do_platform(self, arg):
        """Platform işlemleri: platform <tiktok|instagram|twitter|facebook> <create_account|...>"""
        args = arg.split()
        if len(args) < 2:
            print("Hata: Platform ve işlem belirtilmedi")
            return
        
        platform_name = args[0].lower()
        operation = args[1].lower()
        
        try:
            if platform_name == "tiktok":
                from src.platforms.tiktok import TikTokPlatform
                platform = TikTokPlatform()
            
            elif platform_name == "instagram":
                from src.platforms.instagram import InstagramPlatform
                platform = InstagramPlatform()
            
            elif platform_name == "twitter":
                from src.platforms.twitter import TwitterPlatform
                platform = TwitterPlatform()
            
            elif platform_name == "facebook":
                from src.platforms.facebook import FacebookPlatform
                platform = FacebookPlatform()
            
            else:
                print(f"Hata: Bilinmeyen platform: {platform_name}")
                return
            
            if operation == "create_account":
                print(f"{platform_name.capitalize()} hesabı oluşturuluyor...")
                result = platform.create_account()
                print(f"Sonuç: {'Başarılı' if result else 'Başarısız'}")
            
            else:
                print(f"Hata: Bilinmeyen işlem: {operation}")
        
        except Exception as e:
            print(f"Platform işlemi başarısız: {e}")
    
    def do_api(self, arg):
        """API sunucusunu başlat/durdur: api [start|stop]"""
        args = arg.split()
        if not args:
            print("Hata: Komut belirtilmedi")
            return
        
        command = args[0].lower()
        
        if command == "start":
            print("API sunucusu başlatılıyor...")
            try:
                import uvicorn
                uvicorn.run(
                    "src.api.server:app",
                    host=self.config.api_host,
                    port=self.config.api_port,
                    reload=False,
                    log_level="info"
                )
            except Exception as e:
                print(f"API başlatılamadı: {e}")
        
        elif command == "stop":
            print("API sunucusu durduruluyor...")
            # Not: Bu gerçek bir uygulamada daha karmaşık olurdu
            print("API sunucusu durduruldu")
        
        else:
            print(f"Hata: Bilinmeyen komut: {command}")
    
    def do_config(self, arg):
        """Yapılandırmayı göster/düzenle: config [show|edit]"""
        args = arg.split()
        if not args:
            print("Hata: Komut belirtilmedi")
            return
        
        command = args[0].lower()
        
        if command == "show":
            print("\n--- Mevcut Yapılandırma ---")
            try:
                with open(self.config.config_path or "config.json", 'r') as f:
                    config_data = json.load(f)
                    print(json.dumps(config_data, indent=2))
            except Exception as e:
                print(f"Yapılandırma okunamadı: {e}")
        
        elif command == "edit":
            print("Yapılandırma düzenleniyor...")
            # Not: Bu gerçek bir uygulamada bir metin düzenleyici açardı
            print("Yapılandırma düzenlendi")
        
        else:
            print(f"Hata: Bilinmeyen komut: {command}")
    
    def do_test(self, arg):
        """Testleri çalıştır: test [all|solvers|platforms]"""
        args = arg.split()
        test_type = args[0].lower() if args else "all"
        
        print(f"Testler çalıştırılıyor: {test_type}")
        
        try:
            if test_type in ["all", "solvers"]:
                print("Solver testleri çalıştırılıyor...")
                import pytest
                pytest.main(["-v", "tests/test_solvers.py"])
            
            if test_type in ["all", "platforms"]:
                print("Platform testleri çalıştırılıyor...")
            
            print("Testler tamamlandı")
        
        except Exception as e:
            print(f"Testler çalıştırılamadı: {e}")
    
    def do_exit(self, arg):
        """Sistemden çık"""
        print("Sistem kapatılıyor...")
        self.close()
        return True
    
    def do_quit(self, arg):
        """Sistemden çık"""
        return self.do_exit(arg)
    
    def do_EOF(self, arg):
        """Ctrl+D ile çıkış"""
        print("\n")
        return self.do_exit(arg)
    
    def close(self):
        """Sistemi kapat"""
        try:
            logger.info("Sistem kapatılıyor...")
            
            if hasattr(self.solver, 'stop_advanced_features'):
                self.solver.stop_advanced_features()
            
            if self.executor:
                self.executor.shutdown(wait=True)
            
            logger.info("Sistem kapatıldı")
            
        except Exception as e:
            logger.error(f"Sistem kapatma sırasında hata: {e}")

def main():
    parser = argparse.ArgumentParser(description="Hibrit CAPTCHA Çözüm Sistemi")
    parser.add_argument("--config", "-c", help="Yapılandırma dosyası yolu", default="config.json")
    parser.add_argument("--mode", "-m", choices=["cli", "gui", "api", "batch"], 
                        default="cli", help="Çalışma modu")
    parser.add_argument("--log-level", "-l", choices=["DEBUG", "INFO", "WARNING", "ERROR"], 
                        default="INFO", help="Log seviyesi")
    parser.add_argument("--command", "-C", help="Doğrudan çalıştırılacak komut")
    
    args = parser.parse_args()
    
    config = SystemConfig(
        mode=SystemMode(args.mode),
        config_path=args.config,
        log_level=args.log_level
    )
    
    logging.getLogger().setLevel(getattr(logging, args.log_level))
    
    shell = CaptchaShell(config)
    
    if args.command:
        shell.onecmd(args.command)
        return
    
    try:
        shell.cmdloop()
    except KeyboardInterrupt:
        print("\nÇıkış yapılıyor...")
    finally:
        shell.close()

if __name__ == "__main__":
    main()
