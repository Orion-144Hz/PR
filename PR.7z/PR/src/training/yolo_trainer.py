# src/training/yolo_trainer.py
import os
import json
import random
import logging
from typing import Dict, List, Optional, Tuple, Union
import yaml
import numpy as np
from PIL import Image, ImageDraw
import shutil

logger = logging.getLogger(__name__)

def create_yolo_dataset():
    """YOLO için veri seti oluştur"""
    print("🚀 YOLO için veri seti oluşturuluyor...")
    
    # Dizinleri oluştur
    os.makedirs("data/yolo_dataset/images/train", exist_ok=True)
    os.makedirs("data/yolo_dataset/images/val", exist_ok=True)
    os.makedirs("data/yolo_dataset/labels/train", exist_ok=True)
    os.makedirs("data/yolo_dataset/labels/val", exist_ok=True)
    
    # Sınıf isimleri
    class_names = ["traffic light", "car", "bus", "bicycle", "motorcycle", "fire hydrant"]
    
    # Sınıf isimlerini dosyaya yaz
    with open("data/yolo_dataset/classes.txt", "w") as f:
        for class_name in class_names:
            f.write(f"{class_name}\n")
    
    # Veri seti YAML dosyasını oluştur
    dataset_config = {
        'path': 'data/yolo_dataset',
        'train': 'images/train',
        'val': 'images/val',
        'names': class_names
    }
    
    with open("data/yolo_dataset/dataset.yaml", "w") as f:
        yaml.dump(dataset_config, f)
    
    # Eğitim ve doğrulama için görüntü oluştur
    print("Görüntüler oluşturuluyor...")
    
    # Eğitim görüntüleri
    for i in range(100):
        img = create_yolo_image(class_names)
        img_path = f"data/yolo_dataset/images/train/image_{i:04d}.jpg"
        img.save(img_path)
        
        # Etiket dosyasını oluştur
        label_path = f"data/yolo_dataset/labels/train/image_{i:04d}.txt"
        create_yolo_label(img_path, label_path, class_names)
    
    # Doğrulama görüntüleri
    for i in range(20):
        img = create_yolo_image(class_names)
        img_path = f"data/yolo_dataset/images/val/image_{i:04d}.jpg"
        img.save(img_path)
        
        # Etiket dosyasını oluştur
        label_path = f"data/yolo_dataset/labels/val/image_{i:04d}.jpg"
        create_yolo_label(img_path, label_path, class_names)
    
    print("✅ YOLO veri seti oluşturuldu!")
    print(f"Veri seti konfigürasyonu: data/yolo_dataset/dataset.yaml")

def create_yolo_image(class_names: List[str]) -> Image.Image:
    """YOLO için rastgele görüntü oluştur"""
    # Rastgele bir arka plan rengi
    bg_color = (
        random.randint(200, 255),
        random.randint(200, 255),
        random.randint(200, 255)
    )
    
    # Görüntü oluştur
    img = Image.new('RGB', (640, 640), bg_color)
    draw = ImageDraw.Draw(img)
    
    # Rastgele nesneler ekle
    num_objects = random.randint(1, 5)
    objects = []
    
    for _ in range(num_objects):
        # Rastgele bir sınıf seç
        class_idx = random.randint(0, len(class_names) - 1)
        class_name = class_names[class_idx]
        
        # Rastgele bir konum ve boyut
        x_center = random.randint(50, 590)
        y_center = random.randint(50, 590)
        width = random.randint(30, 100)
        height = random.randint(30, 100)
        
        # Nesneyi çiz
        x1 = x_center - width // 2
        y1 = y_center - height // 2
        x2 = x_center + width // 2
        y2 = y_center + height // 2
        
        # Farklı nesne türleri için farklı şekiller
        if class_name == "traffic light":
            # Kırmızı, sarı veya yeşil daire
            color = random.choice(["red", "yellow", "green"])
            draw.ellipse([x1, y1, x2, y2], fill=color)
        elif class_name in ["car", "bus"]:
            # Dikdörtgen
            color = random.choice(["blue", "green", "red", "yellow"])
            draw.rectangle([x1, y1, x2, y2], fill=color)
        elif class_name == "bicycle":
            # İki daire
            color = "black"
            wheel1_radius = width // 4
            wheel2_radius = width // 4
            draw.ellipse([x1, y1 + height - wheel1_radius, x1 + wheel1_radius*2, y1 + height], fill=color)
            draw.ellipse([x2 - wheel2_radius*2, y1 + height - wheel2_radius, x2, y1 + height], fill=color)
            # Çerçeve
            draw.rectangle([x1, y1, x2, y1 + height - wheel1_radius], outline=color)
        elif class_name == "motorcycle":
            # İki daire ve bir dikdörtgen
            color = "black"
            wheel1_radius = width // 4
            wheel2_radius = width // 4
            draw.ellipse([x1, y1 + height - wheel1_radius, x1 + wheel1_radius*2, y1 + height], fill=color)
            draw.ellipse([x2 - wheel2_radius*2, y1 + height - wheel2_radius, x2, y1 + height], fill=color)
            # Çerçeve
            draw.rectangle([x1, y1, x2, y1 + height - wheel1_radius], fill=color)
        elif class_name == "fire hydrant":
            # Dikdörtgen ve bir daire
            color = "red"
            draw.rectangle([x1, y1, x2, y1 + height], fill=color)
            draw.ellipse([x1 + width//4, y1 - height//4, x2 - width//4, y1 + height//4], fill=color)
        
        # Nesne bilgilerini kaydet
        objects.append({
            'class_idx': class_idx,
            'x_center': x_center / 640,  # Normalize edilmiş koordinatlar
            'y_center': y_center / 640,
            'width': width / 640,
            'height': height / 640
        })
    
    # Gürültü ekle
    for _ in range(100):
        x = random.randint(0, 639)
        y = random.randint(0, 639)
        color = (
            random.randint(0, 255),
            random.randint(0, 255),
            random.randint(0, 255)
        )
        draw.point((x, y), fill=color)
    
    return img

def create_yolo_label(image_path: str, label_path: str, class_names: List[str]):
    """YOLO etiket dosyası oluştur"""
    # Görüntü boyutlarını al
    with Image.open(image_path) as img:
        img_width, img_height = img.size
    
    # Etiket dosyasını oluştur
    with open(label_path, "w") as f:
        # Burada gerçek nesne bilgileri olmalıydı
        # Şimdilik rastgele nesneler oluştur
        num_objects = random.randint(1, 5)
        
        for _ in range(num_objects):
            class_idx = random.randint(0, len(class_names) - 1)
            x_center = random.uniform(0.1, 0.9)
            y_center = random.uniform(0.1, 0.9)
            width = random.uniform(0.05, 0.2)
            height = random.uniform(0.05, 0.2)
            
            # YOLO formatı: class_idx x_center y_center width height
            f.write(f"{class_idx} {x_center} {y_center} {width} {height}\n")

def train_yolo_model():
    """YOLO modelini eğit"""
    try:
        from ultralytics import YOLO
        
        print("🚀 YOLO modeli eğitiliyor...")
        
        # Modeli yükle
        model = YOLO('yolov8n.pt')  # Nano version
        
        # Modeli eğit
        results = model.train(
            data='data/yolo_dataset/dataset.yaml',
            epochs=50,
            imgsz=640,
            batch=16,
            name='yolo_captcha_solver',
            project='data/models'
        )
        
        print("✅ YOLO modeli eğitildi!")
        print(f"Model kaydedildi: data/models/yolo_captcha_solver")
        
        return results
        
    except ImportError:
        print("❌ Ultralytics yüklü değil. Lütfen 'pip install ultralytics' komutuyla yükleyin.")
        return None
    except Exception as e:
        print(f"❌ YOLO modeli eğitilemedi: {e}")
        return None

def main():
    """Ana fonksiyon"""
    print("🚀 YOLO Modeli Eğitimi Başlatılıyor...")
    
    # Model dizinini oluştur
    os.makedirs("data/models", exist_ok=True)
    
    # Veri setini oluştur
    create_yolo_dataset()
    
    # Modeli eğit
    results = train_yolo_model()
    
    if results:
        print("\n✅ YOLO modeli eğitimi tamamlandı!")
    else:
        print("\n❌ YOLO modeli eğitimi başarısız!")

if __name__ == '__main__':
    main()
