# src/training/captcha_trainer.py
import numpy as np
import cv2
import os
import random
import string
import matplotlib.pyplot as plt
import tensorflow as tf
from PIL import Image, ImageDraw, ImageFont
from tensorflow.keras.models import Model
from tensorflow.keras.layers import (Input, Conv2D, MaxPooling2D, BatchNormalization, 
                                     Reshape, LSTM, GRU, Dense, Dropout, Bidirectional)
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from sklearn.model_selection import train_test_split
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.regularizers import l2
import logging

logger = logging.getLogger(__name__)

# Sabitler
IMG_WIDTH = 200
IMG_HEIGHT = 50
CAPTCHA_LENGTH = 5
CHARACTERS = string.digits + string.ascii_uppercase
NUM_CHARACTERS = len(CHARACTERS)
char_to_num = {char: i for i, char in enumerate(CHARACTERS)}
num_to_char = {i: char for i, char in enumerate(CHARACTERS)}

def generate_captcha_image():
    """Rastgele CAPTCHA görüntüsü oluştur"""
    random_text = ''.join(random.choices(CHARACTERS, k=CAPTCHA_LENGTH))
    
    bg_color = (random.randint(200, 255), random.randint(200, 255), random.randint(200, 255))
    image = Image.new('RGB', (IMG_WIDTH, IMG_HEIGHT), bg_color)
    draw = ImageDraw.Draw(image)
    
    try:
        font_size = random.randint(28, 42)
        font = ImageFont.truetype("arial.ttf", size=font_size)
    except IOError:
        font = ImageFont.load_default()
    
    total_width = IMG_WIDTH - 40
    char_width = total_width // CAPTCHA_LENGTH
    
    for i, char in enumerate(random_text):
        x_pos = 20 + i * char_width + random.randint(-8, 8)
        y_pos = random.randint(-3, 8)
        
        text_color = (
            random.randint(0, 120), 
            random.randint(0, 120), 
            random.randint(0, 120)
        )
        
        draw.text((x_pos, y_pos), char, font=font, fill=text_color)
    
    # Gürültü çizgileri ekle
    for _ in range(random.randint(2, 4)):
        draw.line(
            [(random.randint(0, IMG_WIDTH), random.randint(0, IMG_HEIGHT)),
             (random.randint(0, IMG_WIDTH), random.randint(0, IMG_HEIGHT))],
            fill=(random.randint(100, 180), random.randint(100, 180), random.randint(100, 180)),
            width=1
        )
    
    # Gürültü noktaları ekle
    for _ in range(random.randint(20, 40)):
        draw.point(
            (random.randint(0, IMG_WIDTH), random.randint(0, IMG_HEIGHT)),
            fill=(random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
        )
    
    image_np = np.array(image)
    return image_np, random_text

def preprocess_image(image):
    """Görüntüyü ön işle"""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # CLAHE ile kontrastı artır
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    enhanced = clahe.apply(gray)
    
    # Gaussian bulanıklaştırma
    blurred = cv2.GaussianBlur(enhanced, (3, 3), 0)
    
    # Adaptif eşikleme
    thresh = cv2.adaptiveThreshold(
        blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 9, 2
    )
    
    # Morfolojik açma
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2, 2))
    opening = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=1)
    
    # Normalizasyon ve boyutlandırma
    processed_image = np.expand_dims(opening, axis=-1) / 255.0
    return processed_image

def build_crnn_model():
    """CRNN modeli oluştur"""
    input_img = Input(shape=(IMG_HEIGHT, IMG_WIDTH, 1), name='image_input')
    
    x = Conv2D(32, (3, 3), activation='relu', padding='same', kernel_regularizer=l2(0.001))(input_img)
    x = BatchNormalization()(x)
    x = MaxPooling2D((2, 2))(x)
    x = Dropout(0.1)(x)
    
    x = Conv2D(64, (3, 3), activation='relu', padding='same', kernel_regularizer=l2(0.001))(x)
    x = BatchNormalization()(x)
    x = MaxPooling2D((2, 2))(x)
    x = Dropout(0.1)(x)
    
    x = Conv2D(128, (3, 3), activation='relu', padding='same', kernel_regularizer=l2(0.001))(x)
    x = BatchNormalization()(x)
    x = MaxPooling2D((2, 2))(x)
    x = Dropout(0.2)(x)
    
    x = Conv2D(256, (3, 3), activation='relu', padding='same', kernel_regularizer=l2(0.001))(x)
    x = BatchNormalization()(x)
    x = Dropout(0.2)(x)
    shape = x.shape
    x = Reshape((shape[2], shape[1] * shape[3]))(x)
    
    x = Bidirectional(LSTM(256, return_sequences=True, dropout=0.2, recurrent_dropout=0.2))(x)
    x = BatchNormalization()(x)
    
    x = Bidirectional(LSTM(128, return_sequences=True, dropout=0.2, recurrent_dropout=0.2))(x)
    x = BatchNormalization()(x)
    
    x = Bidirectional(LSTM(64, return_sequences=False, dropout=0.2, recurrent_dropout=0.2))(x)
    x = Dropout(0.3)(x)
    
    x = Dense(512, activation='relu', kernel_regularizer=l2(0.001))(x)
    x = BatchNormalization()(x)
    x = Dropout(0.3)(x)
    
    output_layers = []
    for i in range(CAPTCHA_LENGTH):
        output = Dense(NUM_CHARACTERS, activation='softmax', name=f'char_{i}')(x)
        output_layers.append(output)
    
    model = Model(inputs=input_img, outputs=output_layers, name='crnn_captcha_solver')
    
    return model

def character_accuracy(y_true, y_pred):
    """Karakter doğruluğu metriği"""
    predicted_chars = tf.argmax(y_pred, axis=-1)
    correct_predictions = tf.equal(tf.cast(y_true, 'int64'), predicted_chars)
    return tf.reduce_mean(tf.cast(correct_predictions, 'float32'))

def sequence_accuracy(y_true_list, y_pred_list):
    """Sekans doğruluğu metriği"""
    correct_sequences = 0
    total_sequences = len(y_true_list[0])
    
    for i in range(total_sequences):
        sequence_correct = True
        for j in range(CAPTCHA_LENGTH):
            predicted_char = np.argmax(y_pred_list[j][i])
            true_char = y_true_list[j][i]
            if predicted_char != true_char:
                sequence_correct = False
                break
        if sequence_correct:
            correct_sequences += 1
    
    return correct_sequences / total_sequences

def augment_data(images, labels, augment_factor=2):
    """Veri artırma"""
    augmented_images = []
    augmented_labels = []
    
    for img, label in zip(images, labels):
        augmented_images.append(img)
        augmented_labels.append(label)
        
        for _ in range(augment_factor):
            # Döndürme
            angle = random.uniform(-5, 5)
            center = (img.shape[1] // 2, img.shape[0] // 2)
            rotation_matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
            rotated = cv2.warpAffine(img.squeeze(), rotation_matrix, (img.shape[1], img.shape[0]))
            rotated = np.expand_dims(rotated, axis=-1)
            
            # Gürültü ekleme
            noise = np.random.normal(0, 0.05, rotated.shape)
            noisy = np.clip(rotated + noise, 0, 1)
            
            augmented_images.append(noisy)
            augmented_labels.append(label)
    
    return np.array(augmented_images), augmented_labels

def plot_training_history(history):
    """Eğitim geçmişini görselleştir"""
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    
    axes[0, 0].plot(history.history['loss'], label='Eğitim Loss')
    axes[0, 0].plot(history.history['val_loss'], label='Doğrulama Loss')
    axes[0, 0].set_title('Model Loss')
    axes[0, 0].set_xlabel('Epoch')
    axes[0, 0].set_ylabel('Loss')
    axes[0, 0].legend()
    
    if 'char_0_character_accuracy' in history.history:
        axes[0, 1].plot(history.history['char_0_character_accuracy'], label='Eğitim Acc')
        axes[0, 1].plot(history.history['val_char_0_character_accuracy'], label='Doğrulama Acc')
        axes[0, 1].set_title('Karakter 1 Doğruluğu')
        axes[0, 1].set_xlabel('Epoch')
        axes[0, 1].set_ylabel('Accuracy')
        axes[0, 1].legend()
    
    if 'lr' in history.history:
        axes[1, 0].plot(history.history['lr'])
        axes[1, 0].set_title('Learning Rate')
        axes[1, 0].set_xlabel('Epoch')
        axes[1, 0].set_ylabel('LR')
        axes[1, 0].set_yscale('log')
    
    train_losses = history.history['loss']
    val_losses = history.history['val_loss']
    axes[1, 1].plot(range(len(train_losses)), train_losses, label='Eğitim')
    axes[1, 1].plot(range(len(val_losses)), val_losses, label='Doğrulama')
    axes[1, 1].fill_between(range(len(train_losses)), train_losses, alpha=0.3)
    axes[1, 1].fill_between(range(len(val_losses)), val_losses, alpha=0.3)
    axes[1, 1].set_title('Loss Karşılaştırması')
    axes[1, 1].set_xlabel('Epoch')
    axes[1, 1].set_ylabel('Loss')
    axes[1, 1].legend()
    
    plt.tight_layout()
    plt.savefig('training_history.png')
    plt.close()

def main():
    """Ana fonksiyon"""
    print("🚀 CRNN CAPTCHA Modeli Eğitimi Başlatılıyor...")
    
    # Model dizinini oluştur
    os.makedirs("data/models", exist_ok=True)
    
    num_samples = 3000
    images = np.zeros((num_samples, IMG_HEIGHT, IMG_WIDTH, 1))
    labels = []
    
    print("Veri seti oluşturuluyor...")
    for i in range(num_samples):
        img_pil, text = generate_captcha_image()
        images[i] = preprocess_image(img_pil)
        labels.append([char_to_num[char] for char in text])
        
        if (i + 1) % 500 == 0:
            print(f"{i + 1}/{num_samples} tamamlandı...")
    
    print("Veri seti hazır.")
    
    labels_matrix = np.array(labels)
    print("Veri artırma uygulanıyor...")
    
    X_train, X_val, y_train_matrix, y_val_matrix = train_test_split(
        images, labels_matrix, 
        test_size=0.2, 
        random_state=42
    )
    
    print(f"X_train shape: {X_train.shape}")
    print(f"y_train_matrix shape: {y_train_matrix.shape}")
    
    y_train_lists = [y_train_matrix[:, i] for i in range(CAPTCHA_LENGTH)]
    y_val_lists = [y_val_matrix[:, i] for i in range(CAPTCHA_LENGTH)]
    
    train_labels_combined = [list(y_train_matrix[i, :]) for i in range(len(X_train))]
    X_train_aug, train_labels_aug = augment_data(X_train, train_labels_combined, augment_factor=1)
    
    train_labels_aug_matrix = np.array(train_labels_aug)
    
    y_train_aug_lists = [train_labels_aug_matrix[:, i] for i in range(CAPTCHA_LENGTH)]
    y_train = {f'char_{i}': y_train_aug_lists[i] for i in range(CAPTCHA_LENGTH)}
    y_val = {f'char_{i}': y_val_lists[i] for i in range(CAPTCHA_LENGTH)}
    
    print(f"Eğitim seti boyutu: {len(X_train_aug)}")
    print(f"Doğrulama seti boyutu: {len(X_val)}")
    
    model = build_crnn_model()
    
    optimizer = Adam(learning_rate=0.001, beta_1=0.9, beta_2=0.999)
    
    model.compile(
        optimizer=optimizer,
        loss='sparse_categorical_crossentropy',
        metrics=[character_accuracy] * CAPTCHA_LENGTH
    )
    
    model.summary()
    
    # Callback'ler
    early_stopping_loss = EarlyStopping(
        monitor='val_loss',
        patience=15,
        restore_best_weights=True,
        mode='min',
        verbose=1
    )
    
    early_stopping_acc = EarlyStopping(
        monitor='val_char_0_character_accuracy',
        patience=20,
        restore_best_weights=True,
        mode='max',
        verbose=1
    )
    
    model_checkpoint_loss = ModelCheckpoint(
        'data/models/best_captcha_loss.keras',
        monitor='val_loss',
        save_best_only=True,
        mode='min',
        verbose=1
    )
    
    model_checkpoint_acc = ModelCheckpoint(
        'data/models/best_captcha_acc.keras',
        monitor='val_char_0_character_accuracy',
        save_best_only=True,
        mode='max',
        verbose=1
    )
    
    reduce_lr_loss = ReduceLROnPlateau(
        monitor='val_loss',
        factor=0.5,
        patience=8,
        min_lr=1e-7,
        mode='min',
        verbose=1
    )
    
    reduce_lr_acc = ReduceLROnPlateau(
        monitor='val_char_0_character_accuracy',
        factor=0.5,
        patience=10,
        min_lr=1e-7,
        mode='max',
        verbose=1
    )
    
    callbacks = [
        early_stopping_loss,
        early_stopping_acc,
        model_checkpoint_loss,
        model_checkpoint_acc,
        reduce_lr_loss,
        reduce_lr_acc
    ]

    print("Eğitim başlatılıyor...")
    history = model.fit(
        X_train_aug, y_train,
        validation_data=(X_val, y_val),
        epochs=100,
        batch_size=16,   # RAM için daha güvenli
        callbacks=callbacks,
        verbose=1
    )

    print("\nEğitim tamamlandı. Değerlendirme yapılıyor...")
    
    predictions = model.predict(X_val)
    
    y_val_list = [y_val[f'char_{i}'] for i in range(CAPTCHA_LENGTH)]
    seq_acc = sequence_accuracy(y_val_list, predictions)
    print(f"Sekans Doğruluk (Tüm karakterler doğru): {seq_acc:.3f}")
    
    char_accuracies = []
    for i in range(CAPTCHA_LENGTH):
        predicted_chars = np.argmax(predictions[i], axis=1)
        true_chars = y_val[f'char_{i}']
        char_acc = np.mean(predicted_chars == true_chars)
        char_accuracies.append(char_acc)
        print(f"Karakter {i+1} Doğruluğu: {char_acc:.3f}")
    
    print(f"Ortalama Karakter Doğruluğu: {np.mean(char_accuracies):.3f}")
    
    # Eğitim geçmişini görselleştir
    plot_training_history(history)
    
    print("\n✅ Model eğitimi tamamlandı!")
    print(f"Model kaydedildi: data/models/best_captcha_acc.keras")
    print(f"Eğitim geçmişi: training_history.png")

if __name__ == '__main__':
    main()
