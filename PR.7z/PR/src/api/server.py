# src/api/server.py
import asyncio
import aiohttp
import aiofiles
import json
import redis
from typing import AsyncGenerator
import uvicorn
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import prometheus_client as prom
from prometheus_client import Counter, Histogram, Gauge
import psutil
import GPUtil
from datetime import datetime, timedelta
import pytz
import sentry_sdk
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
import jwt
from cryptography.fernet import Fernet
import hashlib
import hmac
import base64
import zlib
import time

# Mevcut modülleri import et
try:
    from ..core.captcha_solver import AdvancedHybridCaptchaSolver, CaptchaResult, CaptchaType
    from ..core.monitoring import ContinuousLearningSystem, PerformanceMonitor
    from ..core.utils import Utils, RateLimiter, Cache
except ImportError as e:
    print(f"Modüller yüklenemedi: {e}")
    print("Lütfen tüm modüllerin aynı dizinde olduğundan emin olun")
    import sys
    sys.exit(1)

# Prometheus metrikleri
REQUEST_COUNT = Counter('captcha_requests_total', 'Total CAPTCHA requests', ['solver', 'status'])
REQUEST_DURATION = Histogram('captcha_request_duration_seconds', 'CAPTCHA request duration')
ACTIVE_SOLVERS = Gauge('captcha_active_solvers', 'Number of active solvers')
CACHE_SIZE = Gauge('captcha_cache_size', 'Cache size')
ERROR_COUNT = Counter('captcha_errors_total', 'Total errors', ['error_type'])

class CaptchaRequest(BaseModel):
    """CAPTCHA isteği modeli"""
    image_data: Optional[str] = None
    image_url: Optional[str] = None
    html_context: Optional[str] = None
    use_cache: bool = True
    timeout: float = 10.0

class CaptchaResponse(BaseModel):
    """CAPTCHA yanıtı modeli"""
    success: bool
    result: str
    confidence: float
    processing_time: float
    captcha_type: str
    solver_used: str
    error_message: Optional[str] = None

class ProductionCaptchaSolver(AdvancedHybridCaptchaSolver):
    """Üretim ortamı için CAPTCHA çözücü"""
    
    def __init__(self, config_path: Optional[str] = None):
        super().__init__(config_path)
        self.redis_client = None
        self.session_pool = None
        self.metrics = {}
        self.health_check = {
            'last_check': None,
            'status': 'healthy',
            'issues': []
        }
        self._setup_redis()
        self._setup_session_pool()
        self._setup_monitoring()
        self._setup_security()
    
    def _setup_redis(self):
        """Redis bağlantısı kur"""
        try:
            redis_config = self.config.get('redis', {
                'host': 'localhost',
                'port': 6379,
                'db': 0,
                'password': None
            })
            
            self.redis_client = redis.Redis(
                host=redis_config['host'],
                port=redis_config['port'],
                db=redis_config['db'],
                password=redis_config['password'],
                decode_responses=True
            )
            
            # Bağlantıyı test et
            self.redis_client.ping()
            print("Redis bağlantısı başarılı")
            
        except Exception as e:
            print(f"Redis bağlantısı başarısız: {e}")
            self.redis_client = None
    
    def _setup_session_pool(self):
        """HTTP session pool oluştur"""
        try:
            connector = aiohttp.TCPConnector(
                limit=100,
                limit_per_host=30,
                ttl_dns_cache=300,
                use_dns_cache=True,
            )
            
            timeout = aiohttp.ClientTimeout(total=30)
            
            self.session_pool = aiohttp.ClientSession(
                connector=connector,
                timeout=timeout,
                headers={
                    'User-Agent': 'HybridCaptchaSolver/1.0'
                }
            )
            
            print("HTTP session pool oluşturuldu")
            
        except Exception as e:
            print(f"Session pool oluşturulamadı: {e}")
            self.session_pool = None
    
    def _setup_monitoring(self):
        """Monitör sistemini kur"""
        # Prometheus metrikleri
        self.metrics.update({
            'requests_total': REQUEST_COUNT,
            'request_duration': REQUEST_DURATION,
            'active_solvers': ACTIVE_SOLVERS,
            'cache_size': CACHE_SIZE,
            'errors_total': ERROR_COUNT
        })
        
        # System monitoring
        self.system_metrics = {
            'cpu_usage': psutil.cpu_percent(),
            'memory_usage': psutil.virtual_memory().percent,
            'disk_usage': psutil.disk_usage('/').percent
        }
        
        # GPU monitoring
        try:
            gpus = GPUtil.getGPUs()
            if gpus:
                self.system_metrics['gpu_usage'] = gpus[0].load * 100
                self.system_metrics['gpu_memory'] = gpus[0].memoryUtil * 100
        except:
            pass
        
        print("Monitör sistemi kuruldu")
    
    def _setup_security(self):
        """Güvenlik ayarları"""
        # JWT secret key
        self.jwt_secret = self.config.get('security', {}).get('jwt_secret', 'default-secret')
        
        # Encryption key
        encryption_key = self.config.get('security', {}).get('encryption_key')
        if encryption_key:
            self.cipher = Fernet(encryption_key.encode())
        else:
            # Generate new key
            key = Fernet.generate_key()
            self.cipher = Fernet(key)
            print("Yeni encryption key oluşturuldu")
        
        # Rate limiting
        self.rate_limits = self.config.get('security', {}).get('rate_limits', {
            'requests_per_minute': 60,
            'requests_per_hour': 1000
        })
        
        print("Güvenlik ayarları yapılandırıldı")
    
    async def solve_captcha_async(self, request: CaptchaRequest) -> CaptchaResponse:
        """Asenkron CAPTCHA çözümü"""
        start_time = time.time()
        
        try:
            # Rate limiting kontrolü
            if not await self._check_rate_limit(request):
                raise HTTPException(status_code=429, detail="Rate limit exceeded")
            
            # Görüntü verisini al
            image_data = await self._get_image_data(request)
            
            # CAPTCHA çözümü yap
            result = await asyncio.get_event_loop().run_in_executor(
                None, self.solve_captcha, image_data, request.html_context, request.use_cache
            )
            
            # Metrikleri güncelle
            self._update_metrics(result, start_time)
            
            return CaptchaResponse(
                success=result.success,
                result=result.result,
                confidence=result.confidence,
                processing_time=result.processing_time,
                captcha_type=result.captcha_type.value,
                solver_used=result.solver_used,
                error_message=result.error_message
            )
            
        except Exception as e:
            processing_time = time.time() - start_time
            print(f"Asenkron CAPTCHA çözümü başarısız: {e}")
            
            # Hata metriklerini güncelle
            ERROR_COUNT.labels(error_type=type(e).__name__).inc()
            
            return CaptchaResponse(
                success=False,
                result="",
                confidence=0.0,
                processing_time=processing_time,
                captcha_type="unknown",
                solver_used="none",
                error_message=str(e)
            )
    
    async def _check_rate_limit(self, request: CaptchaRequest) -> bool:
        """Rate limiting kontrolü"""
        if not self.redis_client:
            return True
        
        try:
            # Client IP'sini al (gerçek uygulamada request context'ten alınmalı)
            client_ip = "127.0.0.1"  # Placeholder
            
            # Rate limit key'leri
            minute_key = f"rate_limit:{client_ip}:minute"
            hour_key = f"rate_limit:{client_ip}:hour"
            
            # Mevcut sayıları al
            current_minute = int(self.redis_client.get(minute_key) or 0)
            current_hour = int(self.redis_client.get(hour_key) or 0)
            
            # Limitleri kontrol et
            if (current_minute >= self.rate_limits['requests_per_minute'] or
                current_hour >= self.rate_limits['requests_per_hour']):
                return False
            
            # Sayıları artır
            pipe = self.redis_client.pipeline()
            pipe.incr(minute_key)
            pipe.expire(minute_key, 60)  # 1 dakika
            pipe.incr(hour_key)
            pipe.expire(hour_key, 3600)  # 1 saat
            pipe.execute()
            
            return True
            
        except Exception as e:
            print(f"Rate limiting kontrolü başarısız: {e}")
            return True
    
    async def _get_image_data(self, request: CaptchaRequest) -> Union[str, bytes]:
        """İstekten görüntü verisini al"""
        if request.image_data:
            # Base64 decoded image data
            try:
                image_bytes = base64.b64decode(request.image_data)
                return image_bytes
            except Exception as e:
                raise ValueError(f"Invalid image data: {e}")
        
        elif request.image_url:
            # URL'den görüntü indir
            try:
                async with self.session_pool.get(request.image_url) as response:
                    if response.status == 200:
                        return await response.read()
                    else:
                        raise ValueError(f"Failed to download image: {response.status}")
            except Exception as e:
                raise ValueError(f"Failed to fetch image from URL: {e}")
        
        else:
            raise ValueError("No image data or URL provided")
    
    def _update_metrics(self, result: CaptchaResult, start_time: float):
        """Metrikleri güncelle"""
        processing_time = time.time() - start_time
        
        # Request metrikleri
        REQUEST_COUNT.labels(
            solver=result.solver_used,
            status='success' if result.success else 'error'
        ).inc()
        
        REQUEST_DURATION.observe(processing_time)
        
        # Cache metrikleri
        if hasattr(self, 'cache'):
            CACHE_SIZE.set(len(self.cache))
        
        # Active solvers
        ACTIVE_SOLVERS.set(len(self.solvers))
    
    async def health_check(self) -> Dict:
        """Sistem sağlık kontrolü"""
        health_status = {
            'timestamp': datetime.now(pytz.UTC).isoformat(),
            'status': 'healthy',
            'components': {},
            'metrics': {}
        }
        
        issues = []
        
        # Redis kontrolü
        if self.redis_client:
            try:
                self.redis_client.ping()
                health_status['components']['redis'] = 'healthy'
            except Exception as e:
                health_status['components']['redis'] = 'unhealthy'
                issues.append(f"Redis connection failed: {e}")
        else:
            health_status['components']['redis'] = 'not_configured'
        
        # Session pool kontrolü
        if self.session_pool:
            try:
                # Test request
                async with self.session_pool.get('http://httpbin.org/get') as response:
                    if response.status == 200:
                        health_status['components']['http_pool'] = 'healthy'
                    else:
                        health_status['components']['http_pool'] = 'unhealthy'
                        issues.append(f"HTTP pool test failed: {response.status}")
            except Exception as e:
                health_status['components']['http_pool'] = 'unhealthy'
                issues.append(f"HTTP pool test failed: {e}")
        else:
            health_status['components']['http_pool'] = 'not_configured'
        
        # Solvers kontrolü
        for name, solver in self.solvers.items():
            try:
                # Test solver
                test_result = solver.solve("test")
                health_status['components'][f'solver_{name}'] = 'healthy'
            except Exception as e:
                health_status['components'][f'solver_{name}'] = 'unhealthy'
                issues.append(f"Solver {name} failed: {e}")
        
        # System metrics
        health_status['metrics'] = {
            'cpu_usage': psutil.cpu_percent(),
            'memory_usage': psutil.virtual_memory().percent,
            'disk_usage': psutil.disk_usage('/').percent,
            'cache_size': len(getattr(self, 'cache', {})),
            'active_solvers': len(self.solvers)
        }
        
        # GPU metrics
        try:
            gpus = GPUtil.getGPUs()
            if gpus:
                health_status['metrics']['gpu_usage'] = gpus[0].load * 100
                health_status['metrics']['gpu_memory'] = gpus[0].memoryUtil * 100
        except:
            pass
        
        # Overall status
        if issues:
            health_status['status'] = 'unhealthy'
            health_status['issues'] = issues
        else:
            health_status['status'] = 'healthy'
        
        # Update health check
        self.health_check = {
            'last_check': datetime.now(pytz.UTC).isoformat(),
            'status': health_status['status'],
            'issues': issues
        }
        
        return health_status
    
    async def cleanup(self):
        """Kaynakları temizle"""
        print("Kaynaklar temizleniyor...")
        
        # Gelişmiş özellikleri durdur
        self.stop_advanced_features()
        
        # Session pool'u kapat
        if self.session_pool:
            await self.session_pool.close()
        
        # Redis bağlantısını kapat
        if self.redis_client:
            self.redis_client.close()
        
        print("Kaynaklar temizlendi")

# FastAPI uygulaması
app = FastAPI(
    title="Hybrid CAPTCHA Solver API",
    description="Advanced hybrid CAPTCHA solving system with OCR and object detection",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Rate limiter
limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter

# Global solver instance
solver = None

@app.on_event("startup")
async def startup_event():
    """Başlangıç event'i"""
    global solver
    solver = ProductionCaptchaSolver()
    solver.start_advanced_features()
    print("API başlatıldı")

@app.on_event("shutdown")
async def shutdown_event():
    """Kapatma event'i"""
    global solver
    if solver:
        await solver.cleanup()
    print("API kapatıldı")

@app.post("/solve", response_model=CaptchaResponse)
@limiter.limit("60/minute")
async def solve_captcha(request: CaptchaRequest):
    """CAPTCHA çözüm endpoint'i"""
    if not solver:
        raise HTTPException(status_code=503, detail="Solver not initialized")
    
    return await solver.solve_captcha_async(request)

@app.get("/health")
async def health_check():
    """Sağlık kontrolü endpoint'i"""
    if not solver:
        raise HTTPException(status_code=503, detail="Solver not initialized")
    
    return await solver.health_check()

@app.get("/metrics")
async def metrics():
    """Prometheus metrikleri endpoint'i"""
    from prometheus_client import generate_latest
    return generate_latest()

@app.get("/stats")
async def get_stats():
    """İstatistikler endpoint'i"""
    if not solver:
        raise HTTPException(status_code=503, detail="Solver not initialized")
    
    return solver.get_detailed_performance()

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "Hybrid CAPTCHA Solver",
        "version": "1.0.0",
        "status": "running"
    }

if __name__ == "__main__":
    # Config dosyası yoksa varsayılan config oluştur
    if not os.path.exists("config.json"):
        default_config = {
            "redis": {
                "host": "localhost",
                "port": 6379,
                "db": 0,
                "password": None
            },
            "security": {
                "jwt_secret": "your-jwt-secret-key",
                "encryption_key": "your-encryption-key",
                "rate_limits": {
                    "requests_per_minute": 60,
                    "requests_per_hour": 1000
                }
            },
            "solvers": {
                "ocr": {"enabled": True, "model_path": "data/models/best_captcha_acc.keras"},
                "yolo": {"enabled": True, "model_path": "data/models/yolo_model.pt"}
            }
        }
        
        with open("config.json", "w") as f:
            json.dump(default_config, f, indent=2)
        
        print("Varsayılan config dosyası oluşturuldu")
    
    # API'yi başlat
    uvicorn.run(
        "src.api.server:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
