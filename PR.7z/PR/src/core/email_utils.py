import os
import time
import random
import string
import json
import logging
import requests
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

logger = logging.getLogger(__name__)

class EmailUtils:
    """E-posta işlemleri için yardımcı sınıf"""
    
    def __init__(self, config_path: Optional[str] = None):
        self.config = self._load_config(config_path)
        self.email_service = None
        self.email_address = None
        self.email_session = None
        
    def _load_config(self, config_path: Optional[str]) -> Dict:
        """Konfigürasyon dosyasını yükle"""
        default_config = {
            "email": {
                "service": "fake-email",
                "domain": "example.com",
                "max_wait_time": 300,
                "check_interval": 15
            }
        }
        
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    user_config = json.load(f)
                    # Merge configs
                    for key, value in user_config.items():
                        if key in default_config and isinstance(value, dict):
                            default_config[key].update(value)
                        else:
                            default_config[key] = value
            except Exception as e:
                logger.error(f"Konfigürasyon dosyası okunamadı: {e}")
        
        return default_config
    
    def create_email(self) -> bool:
        """Geçici e-posta oluştur"""
        try:
            logger.info("Geçici e-posta oluşturuluyor...")
            
            # Fake email service kullan
            if self.config["email"]["service"] == "fake-email":
                from fake_email import Email
                self.email_service = Email()
                email_info = self.email_service.Mail()
                self.email_address = email_info["mail"]
                self.email_session = email_info["session"]
            
            # Diğer e-posta servisleri buraya eklenebilir
            
            logger.info(f"E-posta Adresi: {self.email_address}")
            return True
            
        except Exception as e:
            logger.error(f"E-posta oluşturulurken hata: {e}")
            return False
    
    def get_verification_code(self) -> Optional[str]:
        """Doğrulama kodunu al"""
        max_attempts = self.config["email"]["max_wait_time"] // self.config["email"]["check_interval"]
        
        for attempt in range(max_attempts):
            try:
                logger.info(f"Doğrulama kodu kontrol ediliyor (Deneme {attempt+1}/{max_attempts})...")
                time.sleep(self.config["email"]["check_interval"])
                
                messages = self.email_service.inbox()
                if messages:
                    for message in messages:
                        if isinstance(message, dict) and "message" in message:
                            message_text = message["message"]
                            # Doğrulama kodunu mesajdan çıkar
                            import re
                            code_match = re.search(r'(\d{6})', message_text)
                            if code_match:
                                code = code_match.group(1)
                                logger.info(f"Doğrulama Kodu Bulundu: {code}")
                                return code
                
                logger.info(f"Doğrulama kodu bulunamadı, {self.config['email']['check_interval']} saniye bekleniyor...")
                
            except Exception as e:
                logger.error(f"Doğrulama kodu alınırken hata: {e}")
                time.sleep(self.config["email"]["check_interval"])
        
        logger.error(f"{max_attempts} denemede doğrulama kodu alınamadı!")
        return None
    
    def generate_realistic_email(self, domain: Optional[str] = None) -> str:
        """Gerçekçi e-posta adresi oluştur"""
        if not domain:
            domain = self.config["email"]["domain"]
        
        # Türk isimlerini yükle
        try:
            with open("data/turkish_names.json", 'r', encoding='utf-8') as f:
                names_data = json.load(f)
                first_name = random.choice(names_data["names"])
                last_name = random.choice(names_data["surnames"])
        except (FileNotFoundError, json.JSONDecodeError):
            # Varsayılan isimler
            first_name = random.choice(["ahmet", "mehmet", "mustafa", "ali", "veli"])
            last_name = random.choice(["yilmaz", "kaya", "demir", "celik", "ozturk"])
        
        # Farklı formatlarda e-posta oluştur
        formats = [
            f"{first_name.lower()}.{last_name.lower()}@{domain}",
            f"{first_name.lower()}_{last_name.lower()}@{domain}",
            f"{first_name.lower()}{random.randint(10, 99)}@{domain}",
            f"{first_name.lower()}{last_name.lower()}{random.randint(10, 99)}@{domain}",
            f"{last_name.lower()}{first_name.lower()}@{domain}",
            f"{first_name[0].lower()}{last_name.lower()}@{domain}",
            f"{first_name.lower()}{last_name[0].lower()}@{domain}",
        ]
        
        return random.choice(formats)
    
    def close(self):
        """E-posta servisini kapat"""
        if self.email_service:
            # E-posta servisini kapatma işlemleri
            self.email_service = None
            self.email_address = None
            self.email_session = None
            logger.info("E-posta servisi kapatıldı")
