import os
import json
import time
import logging
import threading
import queue
import numpy as np
from typing import Dict, List, Optional, Union, Any
from dataclasses import dataclass
from datetime import datetime, timedelta
import pytz

logger = logging.getLogger(__name__)

@dataclass
class Alert:
    """Alert veri sınıfı"""
    timestamp: str
    type: str
    message: str
    severity: str  # low, medium, high, critical
    resolved: bool = False
    resolved_at: Optional[str] = None

class ContinuousLearningSystem:
    """Sürekli öğrenme sistemi"""
    
    def __init__(self, solver):
        self.solver = solver
        self.feedback_queue = queue.Queue()
        self.learning_thread = None
        self.model_versions = {}
        self.is_running = False
        
    def start_learning(self):
        """Sürekli öğrenmeyi başlat"""
        if not self.is_running:
            self.is_running = True
            self.learning_thread = threading.Thread(target=self._learning_loop)
            self.learning_thread.daemon = True
            self.learning_thread.start()
            logger.info("Sürekli öğrenme sistemi başlatıldı")
    
    def stop_learning(self):
        """Sürekli öğrenmeyi durdur"""
        self.is_running = False
        if self.learning_thread:
            self.learning_thread.join()
        logger.info("Sürekli öğrenme sistemi durduruldu")
    
    def add_feedback(self, captcha_data, predicted_result: str, actual_result: str, 
                    confidence: float):
        """Kullanıcı geri bildirimi ekle"""
        feedback_data = {
            'timestamp': datetime.now().isoformat(),
            'captcha_data': self._serialize_captcha_data(captcha_data),
            'predicted': predicted_result,
            'actual': actual_result,
            'confidence': confidence,
            'is_correct': predicted_result == actual_result
        }
        
        self.feedback_queue.put(feedback_data)
        logger.info("Geri bildirim eklendi")
    
    def _learning_loop(self):
        """Öğrenme döngüsü"""
        while self.is_running:
            try:
                # Geri bildirimleri topla
                feedback_batch = self._collect_feedback_batch()
                
                if feedback_batch:
                    # Model güncelleme
                    self._update_models(feedback_batch)
                    
                    # Performans analizi
                    self._analyze_performance(feedback_batch)
                
                # Belirli aralıklarla bekle
                time.sleep(60)  # 1 dakika
                
            except Exception as e:
                logger.error(f"Öğrenme döngüsünde hata: {e}")
                time.sleep(30)  # Hata durumunda 30 saniye bekle
    
    def _collect_feedback_batch(self, batch_size: int = 100) -> List[Dict]:
        """Geri bildirim batch'i topla"""
        batch = []
        start_time = time.time()
        
        while len(batch) < batch_size and (time.time() - start_time) < 30:
            try:
                feedback = self.feedback_queue.get(timeout=1)
                batch.append(feedback)
            except queue.Empty:
                break
        
        return batch
    
    def _update_models(self, feedback_batch: List[Dict]):
        """Modelleri geri bildirimlerle güncelle"""
        try:
            # Yanlış tahminleri filtrele
            incorrect_predictions = [f for f in feedback_batch if not f['is_correct']]
            
            if len(incorrect_predictions) > 10:  # Yeterli veri varsa
                logger.info(f"Model güncelleniyor: {len(incorrect_predictions)} yanlış tahmin")
                
                # Dataset oluştur
                dataset = self._create_training_dataset(incorrect_predictions)
                
                # Model güncelle
                self._retrain_models(dataset)
                
        except Exception as e:
            logger.error(f"Model güncelleme başarısız: {e}")
    
    def _serialize_captcha_data(self, captcha_data) -> str:
        """CAPTCHA verisini serialize et"""
        try:
            if isinstance(captcha_data, bytes):
                import base64
                return base64.b64encode(captcha_data).decode('utf-8')
            elif isinstance(captcha_data, str):
                with open(captcha_data, 'rb') as f:
                    import base64
                    return base64.b64encode(f.read()).decode('utf-8')
            elif hasattr(captcha_data, 'tobytes'):  # numpy array
                import base64
                return base64.b64encode(captcha_data.tobytes()).decode('utf-8')
            else:
                return str(captcha_data)
        except Exception as e:
            logger.error(f"Serialize hatası: {e}")
            return ""
    
    def _create_training_dataset(self, feedback_batch: List[Dict]):
        """Eğitim dataset'i oluştur"""
        # Burada gerçek dataset oluşturma mantığı implemente edilmeli
        # Şimdilik placeholder
        image_paths = []
        labels = []
        
        return image_paths, labels
    
    def _retrain_models(self, dataset):
        """Modelleri yeniden eğit"""
        # Burada gerçek yeniden eğitim mantığı implemente edilmeli
        logger.info("Modeller yeniden eğitiliyor")
    
    def _analyze_performance(self, feedback_batch: List[Dict]):
        """Performans analizi yap"""
        total = len(feedback_batch)
        correct = sum(1 for f in feedback_batch if f['is_correct'])
        accuracy = correct / total if total > 0 else 0
        
        avg_confidence = np.mean([f['confidence'] for f in feedback_batch])
        
        logger.info(f"Performans analizi: Doğruluk={accuracy:.3f}, Ortalama Güven={avg_confidence:.3f}")

class PerformanceMonitor:
    """Performans monitörü"""
    
    def __init__(self, solver):
        self.solver = solver
        self.metrics_history = []
        self.alerts = []
        self.monitoring_thread = None
        self.is_running = False
        self.alert_thresholds = {
            'low_success_rate': 0.7,
            'high_processing_time': 5.0,
            'high_error_rate': 0.3
        }
        
    def start_monitoring(self):
        """Monitörü başlat"""
        if not self.is_running:
            self.is_running = True
            self.monitoring_thread = threading.Thread(target=self._monitoring_loop)
            self.monitoring_thread.daemon = True
            self.monitoring_thread.start()
            logger.info("Performans monitörü başlatıldı")
    
    def stop_monitoring(self):
        """Monitörü durdur"""
        self.is_running = False
        if self.monitoring_thread:
            self.monitoring_thread.join()
        logger.info("Performans monitörü durduruldu")
    
    def _monitoring_loop(self):
        """Monitör döngüsü"""
        while self.is_running:
            try:
                # Metrikleri topla
                metrics = self.solver.get_performance_metrics()
                
                # Geçmişe ekle
                self.metrics_history.append({
                    'timestamp': datetime.now().isoformat(),
                    'metrics': metrics.copy()
                })
                
                # Anomali tespiti
                self._detect_anomalies(metrics)
                
                # Rapor oluştur
                self._generate_report()
                
                # 5 dakika bekle
                time.sleep(300)
                
            except Exception as e:
                logger.error(f"Monitör döngüsünde hata: {e}")
                time.sleep(60)
    
    def _detect_anomalies(self, metrics: Dict):
        """Anomali tespiti"""
        # Başarı oranı düşükse alarm
        success_rate = metrics['successful_solves'] / max(metrics['total_requests'], 1)
        if success_rate < self.alert_thresholds['low_success_rate']:
            alert = Alert(
                timestamp=datetime.now().isoformat(),
                type='low_success_rate',
                message=f'Düşük başarı oranı: {success_rate:.3f}',
                severity='high'
            )
            self.alerts.append(alert)
            logger.warning(alert.message)
        
        # Ortalama işlem süresi yüksekse alarm
        if metrics['average_processing_time'] > self.alert_thresholds['high_processing_time']:
            alert = Alert(
                timestamp=datetime.now().isoformat(),
                type='high_processing_time',
                message=f'Yüksek işlem süresi: {metrics["average_processing_time"]:.3f}s',
                severity='medium'
            )
            self.alerts.append(alert)
            logger.warning(alert.message)
        
        # Hata oranı yüksekse alarm
        error_rate = metrics['failed_solves'] / max(metrics['total_requests'], 1)
        if error_rate > self.alert_thresholds['high_error_rate']:
            alert = Alert(
                timestamp=datetime.now().isoformat(),
                type='high_error_rate',
                message=f'Yüksek hata oranı: {error_rate:.3f}',
                severity='high'
            )
            self.alerts.append(alert)
            logger.warning(alert.message)
    
    def _generate_report(self):
        """Performans raporu oluştur"""
        if len(self.metrics_history) < 2:
            return
        
        # Son iki metrik karşılaştırması
        current = self.metrics_history[-1]
        previous = self.metrics_history[-2]
        
        report = {
            'timestamp': current['timestamp'],
            'changes': {}
        }
        
        # Değişimleri hesapla
        for key in current['metrics']:
            if key in previous['metrics']:
                if isinstance(current['metrics'][key], (int, float)):
                    change = current['metrics'][key] - previous['metrics'][key]
                    report['changes'][key] = change
        
        logger.info(f"Performans raporu oluşturuldu: {len(report['changes'])} metrik değişti")
    
    def get_metrics_history(self, limit: int = 100) -> List[Dict]:
        """Metrik geçmişini getir"""
        return self.metrics_history[-limit:]
    
    def get_alerts(self, limit: int = 50) -> List[Alert]:
        """Alarmları getir"""
        return self.alerts[-limit:]
    
    def resolve_alert(self, alert_index: int):
        """Alarmı çözüldü olarak işaretle"""
        if 0 <= alert_index < len(self.alerts):
            self.alerts[alert_index].resolved = True
            self.alerts[alert_index].resolved_at = datetime.now().isoformat()
            logger.info(f"Alarm çözüldü: {self.alerts[alert_index].message}")
    
    def set_alert_threshold(self, threshold_name: str, value: float):
        """Alarm eşiğini ayarla"""
        if threshold_name in self.alert_thresholds:
            self.alert_thresholds[threshold_name] = value
            logger.info(f"Alarm eşiği güncellendi: {threshold_name} = {value}")
        else:
            logger.warning(f"Bilinmeyen alarm eşiği: {threshold_name}")

class BusinessMetricsCollector:
    """Business logic specific metrics collector"""
    
    def __init__(self):
        self.metrics = {
            'captcha_success_rate': [],
            'solver_performance': {},
            'error_patterns': {},
            'processing_time_trends': [],
            'user_satisfaction': []
        }
        self.lock = threading.Lock()
    
    def record_captcha_result(self, result):
        """CAPTCHA sonucunu kaydet"""
        with self.lock:
            # Success rate tracking
            self.metrics['captcha_success_rate'].append({
                'timestamp': datetime.now().isoformat(),
                'success': result.success,
                'captcha_type': result.captcha_type.value,
                'solver_used': result.solver_used
            })
            
            # Processing time trends
            self.metrics['processing_time_trends'].append({
                'timestamp': datetime.now().isoformat(),
                'processing_time': result.processing_time,
                'captcha_type': result.captcha_type.value,
                'solver_used': result.solver_used
            })
            
            # Solver performance
            solver_key = f"{result.captcha_type.value}_{result.solver_used}"
            if solver_key not in self.metrics['solver_performance']:
                self.metrics['solver_performance'][solver_key] = {
                    'total': 0,
                    'successful': 0,
                    'avg_time': 0,
                    'times': []
                }
            
            solver_perf = self.metrics['solver_performance'][solver_key]
            solver_perf['total'] += 1
            if result.success:
                solver_perf['successful'] += 1
            solver_perf['times'].append(result.processing_time)
            solver_perf['avg_time'] = sum(solver_perf['times']) / len(solver_perf['times'])
            
            # Error patterns
            if not result.success and result.error_message:
                error_key = result.error_message[:100]  # İlk 100 karakter
                if error_key not in self.metrics['error_patterns']:
                    self.metrics['error_patterns'][error_key] = 0
                self.metrics['error_patterns'][error_key] += 1
    
    def get_success_rate_trend(self, hours: int = 24) -> Dict:
        """Son saatlerdeki başarı trendini getir"""
        with self.lock:
            cutoff = datetime.now(pytz.UTC) - timedelta(hours=hours)
            recent_results = [
                r for r in self.metrics['captcha_success_rate']
                if datetime.fromisoformat(r['timestamp']) > cutoff
            ]
            
            if not recent_results:
                return {'trend': [], 'rate': 0}
            
            trend_data = []
            for i in range(0, len(recent_results), max(1, len(recent_results) // 10)):
                subset = recent_results[:i+1]
                rate = sum(r['success'] for r in subset) / len(subset)
                trend_data.append({
                    'point': i,
                    'rate': rate,
                    'timestamp': subset[-1]['timestamp']
                })
            
            return {
                'trend': trend_data,
                'rate': sum(r['success'] for r in recent_results) / len(recent_results)
            }
    
    def get_solver_comparison(self) -> Dict:
        """Solver performans karşılaştırması"""
        with self.lock:
            comparison = {}
            for solver_key, perf in self.metrics['solver_performance'].items():
                comparison[solver_key] = {
                    'success_rate': perf['successful'] / perf['total'] if perf['total'] > 0 else 0,
                    'avg_processing_time': perf['avg_time'],
                    'total_requests': perf['total']
                }
            return comparison
    
    def get_error_analysis(self) -> Dict:
        """Hata analizi"""
        with self.lock:
            return dict(sorted(self.metrics['error_patterns'].items(), 
                             key=lambda x: x[1], reverse=True)[:10])
