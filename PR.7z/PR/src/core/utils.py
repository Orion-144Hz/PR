import os
import time
import random
import string
import json
import logging
import hashlib
import base64
import pickle
from typing import Dict, List, Optional, Tuple, Union, Any
from datetime import datetime, timedelta
import pytz

logger = logging.getLogger(__name__)

class Utils:
    """Genel yardımcı fonksiyonlar"""
    
    @staticmethod
    def generate_password(length: int = 12, use_uppercase: bool = True, 
                        use_lowercase: bool = True, use_numbers: bool = True, 
                        use_special: bool = True) -> str:
        """Güvenli şifre üreteci"""
        uppercase_chars = string.ascii_uppercase
        lowercase_chars = string.ascii_lowercase
        number_chars = string.digits
        special_chars = "!@#$%^&*()-_=+[]{}|;:,.<>?"
        
        char_pool = ""
        if use_uppercase: char_pool += uppercase_chars
        if use_lowercase: char_pool += lowercase_chars
        if use_numbers: char_pool += number_chars
        if use_special: char_pool += special_chars
        
        # En az bir karakter türü seçilmiş olmalı
        if not char_pool:
            char_pool = lowercase_chars + number_chars  # Varsayılan
        
        password = []
        
        # Her bir karakter türünden en az bir tane ekle
        if use_uppercase:
            password.append(random.choice(uppercase_chars))
        if use_lowercase:
            password.append(random.choice(lowercase_chars))
        if use_numbers:
            password.append(random.choice(number_chars))
        if use_special:
            password.append(random.choice(special_chars))
        
        # Geri kalan karakterleri rastgele ekle
        for _ in range(length - len(password)):
            password.append(random.choice(char_pool))
        
        # Karakterleri karıştır
        random.shuffle(password)
        
        return "".join(password)
    
    @staticmethod
    def generate_username(names_data: Dict) -> str:
        """Gerçekçi kullanıcı adı oluştur"""
        try:
            # Türk isimlerini JSON dosyasından yükle
            first_name = random.choice(names_data["names"])
            
            # %50 ihtimalle soyisim, %50 ihtimalle şehir
            if random.random() < 0.5:
                second_part = random.choice(names_data["surnames"])
            else:
                second_part = random.choice(names_data["locations"])
            
            # Farklı formatlarda kullanıcı adı oluştur
            formats = [
                f"{first_name.lower()}{second_part.lower()}",
                f"{first_name.lower()}.{second_part.lower()}",
                f"{first_name.lower()}_{second_part.lower()}",
                f"{first_name.lower()}{random.randint(10, 99)}",
                f"{first_name.lower()}{second_part.lower()}{random.randint(10, 99)}",
                f"{second_part.lower()}{first_name.lower()}",
                f"{first_name[0].lower()}{second_part.lower()}",
                f"{first_name.lower()}{second_part[0].lower()}",
            ]
            username = random.choice(formats)
        except (KeyError, IndexError):
            # Varsayılan format
            username = f"user_{int(time.time())}_{random.randint(100,999)}"
        
        return username
    
    @staticmethod
    def load_json_file(file_path: str, default_data: Any = None) -> Any:
        """JSON dosyasını yükle"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            logger.warning(f"JSON dosyası yüklenemedi: {file_path}, Hata: {e}")
            return default_data
    
    @staticmethod
    def save_json_file(file_path: str, data: Any) -> bool:
        """Veriyi JSON dosyasına kaydet"""
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            logger.error(f"JSON dosyası kaydedilemedi: {file_path}, Hata: {e}")
            return False
    
    @staticmethod
    def calculate_hash(data: Union[str, bytes, Dict]) -> str:
        """Verinin hash'ini hesapla"""
        if isinstance(data, str):
            data = data.encode('utf-8')
        elif isinstance(data, dict):
            data = json.dumps(data, sort_keys=True).encode('utf-8')
        
        return hashlib.md5(data).hexdigest()
    
    @staticmethod
    def base64_encode(data: Union[str, bytes]) -> str:
        """Veriyi base64'e encode et"""
        if isinstance(data, str):
            data = data.encode('utf-8')
        return base64.b64encode(data).decode('utf-8')
    
    @staticmethod
    def base64_decode(data: str) -> bytes:
        """Base64 veriyi decode et"""
        return base64.b64decode(data)
    
    @staticmethod
    def serialize_object(obj: Any) -> bytes:
        """Objeyi serialize et"""
        return pickle.dumps(obj)
    
    @staticmethod
    def deserialize_object(data: bytes) -> Any:
        """Serialize edilmiş objeyi deserialize et"""
        return pickle.loads(data)
    
    @staticmethod
    def get_timestamp() -> str:
        """Mevcut zaman damgasını al"""
        return datetime.now(pytz.UTC).isoformat()
    
    @staticmethod
    def format_duration(seconds: float) -> str:
        """Saniyeyi insan tarafından okunabilir formata çevir"""
        if seconds < 60:
            return f"{seconds:.2f} saniye"
        elif seconds < 3600:
            return f"{seconds/60:.2f} dakika"
        else:
            return f"{seconds/3600:.2f} saat"
    
    @staticmethod
    def create_directory(path: str) -> bool:
        """Dizin oluştur"""
        try:
            os.makedirs(path, exist_ok=True)
            return True
        except Exception as e:
            logger.error(f"Dizin oluşturulamadı: {path}, Hata: {e}")
            return False
    
    @staticmethod
    def file_exists(file_path: str) -> bool:
        """Dosyanın var olup olmadığını kontrol et"""
        return os.path.isfile(file_path)
    
    @staticmethod
    def directory_exists(dir_path: str) -> bool:
        """Dizinin var olup olmadığını kontrol et"""
        return os.path.isdir(dir_path)
    
    @staticmethod
    def get_file_size(file_path: str) -> int:
        """Dosya boyutunu al"""
        try:
            return os.path.getsize(file_path)
        except Exception as e:
            logger.error(f"Dosya boyutu alınamadı: {file_path}, Hata: {e}")
            return 0
    
    @staticmethod
    def delete_file(file_path: str) -> bool:
        """Dosyayı sil"""
        try:
            os.remove(file_path)
            return True
        except Exception as e:
            logger.error(f"Dosya silinemedi: {file_path}, Hata: {e}")
            return False
    
    @staticmethod
    def retry_function(func, max_attempts: int = 3, delay: float = 1.0, 
                      backoff: float = 2.0, exceptions: Tuple = (Exception,)):
        """Fonksiyonu belirli sayıda deneme"""
        for attempt in range(max_attempts):
            try:
                return func()
            except exceptions as e:
                if attempt == max_attempts - 1:
                    raise
                logger.warning(f"Fonksiyon başarısız, {delay} saniye sonra tekrar denenecek. Deneme: {attempt+1}/{max_attempts}, Hata: {e}")
                time.sleep(delay)
                delay *= backoff

class RateLimiter:
    """Rate limiting için yardımcı sınıf"""
    
    def __init__(self, max_requests_per_minute: int = 60, max_requests_per_hour: int = 1000):
        self.max_requests_per_minute = max_requests_per_minute
        self.max_requests_per_hour = max_requests_per_hour
        self.requests = []
        self.lock = threading.Lock()
    
    def can_make_request(self) -> bool:
        """İstek yapılabilir mi kontrol et"""
        with self.lock:
            now = datetime.now()
            
            # Eski istekleri temizle
            self.requests = [req_time for req_time in self.requests 
                           if now - req_time < timedelta(hours=1)]
            
            # Dakika bazlı kontrol
            minute_requests = [req_time for req_time in self.requests 
                             if now - req_time < timedelta(minutes=1)]
            
            # Saat bazlı kontrol
            hour_requests = self.requests
            
            return (len(minute_requests) < self.max_requests_per_minute and 
                   len(hour_requests) < self.max_requests_per_hour)
    
    def record_request(self):
        """İsteği kaydet"""
        with self.lock:
            self.requests.append(datetime.now())
    
    def wait_if_needed(self):
        """Gerekirse bekle"""
        while not self.can_make_request():
            time.sleep(1)

class Cache:
    """Basit bir cache implementasyonu"""
    
    def __init__(self, max_size: int = 1000, ttl: int = 3600):
        self.max_size = max_size
        self.ttl = ttl  # Time to live in seconds
        self.cache = {}
        self.access_times = {}
        self.lock = threading.Lock()
    
    def get(self, key: str) -> Any:
        """Cache'ten veri al"""
        with self.lock:
            if key not in self.cache:
                return None
            
            # TTL kontrolü
            if time.time() - self.access_times[key] > self.ttl:
                self._remove_key(key)
                return None
            
            # Erişim zamanını güncelle
            self.access_times[key] = time.time()
            return self.cache[key]
    
    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """Cache'e veri ekle"""
        with self.lock:
            # Cache boyutunu kontrol et
            if len(self.cache) >= self.max_size:
                self._evict()
            
            self.cache[key] = value
            self.access_times[key] = time.time()
            
            # Özel TTL ayarla
            if ttl is not None:
                # Bu basit implementasyonda TTL'yi ayrı tutmuyoruz
                pass
            
            return True
    
    def delete(self, key: str) -> bool:
        """Cache'ten veri sil"""
        with self.lock:
            return self._remove_key(key)
    
    def clear(self):
        """Cache'i temizle"""
        with self.lock:
            self.cache.clear()
            self.access_times.clear()
    
    def size(self) -> int:
        """Cache boyutunu al"""
        with self.lock:
            return len(self.cache)
    
    def _remove_key(self, key: str) -> bool:
        """Anahtarı cache'ten kaldır"""
        if key in self.cache:
            del self.cache[key]
            del self.access_times[key]
            return True
        return False
    
    def _evict(self):
        """Cache'ten en eski veriyi çıkar"""
        if not self.access_times:
            return
        
        # En eski erşim zamanını bul
        oldest_key = min(self.access_times.keys(), key=lambda k: self.access_times[k])
        self._remove_key(oldest_key)
