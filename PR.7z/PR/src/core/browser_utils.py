import os
import time
import random
import json
import logging
from typing import Dict, List, Optional, Tuple, Union
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException, TimeoutException, ElementNotInteractableException
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from fake_useragent import UserAgent

logger = logging.getLogger(__name__)

class BrowserUtils:
    
    def __init__(self, config_path: Optional[str] = None):
        self.config = self._load_config(config_path)
        self.driver = None
        self.wait = None
        self.current_proxy = None
        
    def _load_config(self, config_path: Optional[str]) -> Dict:
        default_config = {
            "browser": {
                "geckodriver_path": "/usr/local/bin/geckodriver",
                "headless": True,
                "window_size": [1920, 1080]
            }
        }
        
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    user_config = json.load(f)
                    # Merge configs
                    for key, value in user_config.items():
                        if key in default_config and isinstance(value, dict):
                            default_config[key].update(value)
                        else:
                            default_config[key] = value
            except Exception as e:
                logger.error(f"Konfigürasyon dosyası okunamadı: {e}")
        
        return default_config
    
    def rotate_proxy(self, proxy_file: str = "data/proxies.txt") -> bool:
        try:
            with open(proxy_file, "r") as f:
                proxies = [line.strip() for line in f if line.strip() and ":" in line]
            
            if not proxies:
                logger.warning("Proxy listesi boş. 300 saniye bekleniyor.")
                time.sleep(300)
                return False

            random.shuffle(proxies)
            
            for proxy_address in proxies:
                try:
                    import socket
                    ip, port_str = proxy_address.split(":")
                    port = int(port_str)
                    
                    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    s.settimeout(3)
                    s.connect((ip, port))
                    s.close()

                    self.current_proxy = f"socks5://{proxy_address}"
                    logger.info(f"Çalışan Proxy Bulundu ve Aktif Edildi: {self.current_proxy}")
                    return True
                except (ValueError, socket.error, socket.timeout):
                    logger.debug(f"Ölü Proxy Atlattı: {proxy_address}")
                    continue
            
            logger.warning("Cephanelikte çalışan proxy bulunamadı. Lojistik destek bekleniyor (180 saniye)...")
            time.sleep(180)
            return False

        except FileNotFoundError:
            logger.error(f"Cephanelik dosyası '{proxy_file}' bulunamadı!")
            return False
    
    def load_fingerprint(self, fingerprint_file: str = "data/fingerprints.json") -> Dict:
        try:
            with open(fingerprint_file, 'r') as f:
                db = json.load(f)
            return random.choice(db["browser_profiles"])
        except (FileNotFoundError, json.JSONDecodeError):
            logger.warning("'fingerprints.json' bulunamadı veya bozuk. Varsayılan parmak izi kullanılıyor.")
            ua = UserAgent()
            return {
                "user_agent": ua.random,
                "languages": ["en-US", "en"],
                "screen_resolution": [1920, 1080]
            }
    
    def start_browser(self, proxy: Optional[str] = None) -> webdriver.Firefox:
        if proxy:
            self.current_proxy = proxy
        
        fingerprint = self.load_fingerprint()
        logger.info(f"Kimlik Yüklendi: {fingerprint['user_agent'][:60]}...")
        
        options = Options()
        
        options.set_preference("general.useragent.override", fingerprint["user_agent"])
        options.set_preference('intl.accept_languages', ','.join(fingerprint["languages"]))
        
        if self.current_proxy:
            proxy_host, proxy_port = self.current_proxy.split('://')[1].split(':')
            options.set_preference('network.proxy.type', 1)
            options.set_preference('network.proxy.socks', proxy_host)
            options.set_preference('network.proxy.socks_port', int(proxy_port))
            options.set_preference('network.proxy.socks_remote_dns', True)
        
        if self.config["browser"]["headless"]:
            options.add_argument("-headless")
        
        options.set_preference("dom.webdriver.enabled", False)
        options.set_preference('useAutomationExtension', False)
        
        options.set_preference("browser.cache.disk.enable", False)
        options.set_preference("browser.cache.memory.enable", False)
        options.set_preference("browser.cache.offline.enable", False)
        options.set_preference("network.http.pipelining", True)
        options.set_preference("network.http.pipelining.maxrequests", 8)
        options.set_preference("network.http.proxy.pipelining", True)

        try:
            service = Service(executable_path=self.config["browser"]["geckodriver_path"])
            
            self.driver = webdriver.Firefox(service=service, options=options)
            self.driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
            self.wait = WebDriverWait(self.driver, 20)
            
            width, height = self.config["browser"]["window_size"]
            self.driver.set_window_size(width, height)
            
            return self.driver
            
        except Exception as e:
            logger.error(f"Tarayıcı başlatılamadı: {e}")
            raise
    
    def human_mouse_movement(self, element):
        """İnsan benzeri fare hareketleri"""
        actions = ActionChains(self.driver)
        actions.move_to_element(element)
        for _ in range(random.randint(3, 6)):
            x_offset = random.gauss(0, 4)
            y_offset = random.gauss(0, 4)
            actions.move_by_offset(x_offset, y_offset).pause(random.uniform(0.05, 0.2))
        actions.click().perform()
    
    def human_typing(self, element, text):
        """İnsan benzeri yazma davranışı"""
        for char in text:
            if random.random() < 0.05:
                wrong_char = chr(ord(char) + random.randint(-1, 1))
                self.driver.execute_script("arguments[0].value += arguments[1];", element, wrong_char)
                time.sleep(random.uniform(0.1, 0.3))
                self.driver.execute_script("arguments[0].value = arguments[0].value.slice(0, -1);", element)
            
            self.driver.execute_script("arguments[0].value += arguments[1];", element, char)
            element.send_keys(Keys.NULL)
            time.sleep(max(0.05, random.gauss(0.1, 0.04)))
    
    def simulate_cognitive_delay(self, complexity=1):
        delay = random.gauss(1.2, 0.4) * complexity
        time.sleep(max(0.5, delay))
    
    def close_browser(self):
        if self.driver:
            self.driver.quit()
            self.driver = None
            self.wait = None
            logger.info("Tarayıcı kapatıldı")
    
    def take_screenshot(self, filename: str) -> bool:
        if not self.driver:
            logger.error("Tarayıcı başlatılmamış")
            return False
        
        try:
            self.driver.save_screenshot(filename)
            logger.info(f"Ekran görüntüsü alındı: {filename}")
            return True
        except Exception as e:
            logger.error(f"Ekran görüntüsü alınamadı: {e}")
            return False
    
    def wait_and_click(self, locator: Tuple[str, str], timeout: int = 10) -> bool:
        try:
            element = self.wait.until(EC.element_to_be_clickable(locator))
            self.human_mouse_movement(element)
            return True
        except TimeoutException:
            logger.warning(f"Element bulunamadı veya tıklanabilir değil: {locator}")
            return False
        except Exception as e:
            logger.error(f"Tıklama hatası: {e}")
            return False
    
    def wait_and_type(self, locator: Tuple[str, str], text: str, timeout: int = 10) -> bool:
        try:
            element = self.wait.until(EC.visibility_of_element_located(locator))
            self.human_typing(element, text)
            return True
        except TimeoutException:
            logger.warning(f"Element bulunamadı: {locator}")
            return False
        except Exception as e:
            logger.error(f"Yazma hatası: {e}")
            return False
