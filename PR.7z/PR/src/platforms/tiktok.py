import os
import time
import random
import json
import logging
from typing import Dict, List, Optional, Tuple, Union

from ..core.browser_utils import BrowserUtils
from ..core.email_utils import EmailUtils
from ..core.utils import Utils
from ..core.captcha_solver import AdvancedHybridCaptchaSolver, CaptchaResult

logger = logging.getLogger(__name__)

class TikTokPlatform:
    """TikTok platformu için otomasyon sınıfı"""
    
    def __init__(self, config_path: Optional[str] = None):
        self.config = self._load_config(config_path)
        self.browser_utils = BrowserUtils(config_path)
        self.email_utils = EmailUtils(config_path)
        self.utils = Utils()
        self.captcha_solver = AdvancedHybridCaptchaSolver(config_path)
        
        # Türk isimlerini JSON dosyasından yükle
        self.turkish_names = self._load_turkish_names()
        
        # Proxy ve tarayıcı ayarları
        self.driver = None
        self.wait = None
        self.current_proxy = None
        
    def _load_config(self, config_path: Optional[str]) -> Dict:
        """Konfigürasyon dosyasını yükle"""
        default_config = {
            "browser": {
                "geckodriver_path": "/usr/local/bin/geckodriver",
                "headless": True,
                "window_size": [1920, 1080]
            },
            "email": {
                "service": "fake-email",
                "domain": "example.com",
                "max_wait_time": 300,
                "check_interval": 15
            },
            "captcha": {
                "model_path": "data/models/best_captcha_acc.keras",
                "confidence_threshold": 0.7
            }
        }
        
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    user_config = json.load(f)
                    # Merge configs
                    for key, value in user_config.items():
                        if key in default_config and isinstance(value, dict):
                            default_config[key].update(value)
                        else:
                            default_config[key] = value
            except Exception as e:
                logger.error(f"Konfigürasyon dosyası okunamadı: {e}")
        
        return default_config
    
    def _load_turkish_names(self) -> Dict:
        """Türk isimlerini JSON dosyasından yükle"""
        try:
            with open("data/turkish_names.json", 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            logger.warning("'turkish_names.json' bulunamadı. Varsayılan isimler kullanılıyor.")
            return {
                "names": ["Ahmet", "Mehmet", "Mustafa"],
                "surnames": ["Yılmaz", "Kaya", "Demir"],
                "locations": ["İstanbul", "Ankara", "İzmir"]
            }
        except json.JSONDecodeError:
            logger.warning("'turkish_names.json' dosyası bozuk. Varsayılan isimler kullanılıyor.")
            return {
                "names": ["Ahmet", "Mehmet", "Mustafa"],
                "surnames": ["Yılmaz", "Kaya", "Demir"],
                "locations": ["İstanbul", "Ankara", "İzmir"]
            }
    
    def create_account(self) -> bool:
        """TikTok hesabı oluştur"""
        try:
            # Adım 1: Proxy döndür
            if not self.browser_utils.rotate_proxy("data/proxies.txt"):
                return False

            # Adım 2: Tarayıcıyı başlat
            self.driver = self.browser_utils.start_browser(self.current_proxy)
            self.wait = self.browser_utils.wait

            # Adım 3: E-posta oluştur
            if not self.email_utils.create_email():
                return False

            # Adım 4: TikTok'a git
            self.driver.get("https://www.tiktok.com/signup/phone-or-email/email")
            
            # Dil ayarlarını yap
            self._set_english_language()
            time.sleep(2)
            
            # Çerez kabul et
            self._accept_cookies()
            
            # Adım 5: Doğum tarihi seç
            self._select_birth_date()
            
            # Adım 6: E-posta ve şifre gir
            email_field = self.wait.until(self._find_element(("css selector", "input[name='email']")))
            self.browser_utils.human_typing(email_field, self.email_utils.email_address)
            
            # Güçlü şifre oluştur
            password = self.utils.generate_password(
                length=12, 
                use_uppercase=True, 
                use_lowercase=True, 
                use_numbers=True, 
                use_special=True
            )
            logger.info(f"Oluşturulan Şifre: {password}")
            
            # Şifre alanını doldur
            password_field = self.wait.until(self._find_element(("css selector", "input[type='password']")))
            self.browser_utils.human_typing(password_field, password)
            
            self.browser_utils.simulate_cognitive_delay(1)

            # Adım 7: Kod gönder butonuna tıkla
            send_code_button = self.wait.until(self._find_element(("xpath", "//button[contains(., 'Send code')]")))
            self.browser_utils.human_mouse_movement(send_code_button)
            logger.info("Doğrulama kodu gönderildi.")
            
            # Adım 8: Captcha'yı çöz
            logger.info("Captcha çözülüyor...")
            captcha_solved = self._solve_captcha()
            
            if captcha_solved:
                logger.info("Captcha başarıyla çözüldü!")
            else:
                logger.warning("Captcha çözülemedi, 10 saniye manuel çözüm süresi...")
                time.sleep(10)
            
            # Adım 9: Doğrulama kodunu e-postadan al
            verification_code = self.email_utils.get_verification_code()
            if not verification_code:
                logger.error("Doğrulama kodu alınamadı!")
                return False
            
            # Adım 10: Kod giriş alanını doldur
            code_field = self.wait.until(self._find_element(("css selector", "input[placeholder*='code']")))
            self.browser_utils.human_typing(code_field, verification_code)
            
            self.browser_utils.simulate_cognitive_delay(1)
            
            # Adım 11: İleri butonuna tıkla
            next_button = self.wait.until(self._find_element(("xpath", "//button[contains(., 'Next')]")))
            self.browser_utils.human_mouse_movement(next_button)
            
            logger.info("Hesap oluşturma adımı tamamlandı. Kullanıcı adı bekleniyor...")
            
            # Adım 12: Kullanıcı adı oluştur ve kaydet
            return self._create_username_and_save(password)
            
        except Exception as e:
            logger.error(f"Hesap oluşturulurken hata: {e}")
            if self.driver:
                error_filename = f"error_{int(time.time())}.png"
                self.browser_utils.take_screenshot(error_filename)
                logger.info(f"Hata ekran görüntüsü kaydedildi: {error_filename}")
            return False
        finally:
            if self.driver:
                self.driver.quit()
                self.driver = None
                self.wait = None
            logger.info("Oturum sonlandırıldı.")
    
    def _set_english_language(self):
        """Sayfa dilini İngilizce'ye ayarlamak için"""
        try:
            # Dil seçeneklerini kontrol et
            language_options = self.driver.find_elements("css selector", "div[role='combobox'], select")
            
            for option in language_options:
                try:
                    # Dil seçeneğini kontrol et
                    option_text = option.get_attribute('aria-label') or option.text or ""
                    if any(word in option_text.lower() for word in ['language', 'dil', 'sprache', 'langue']):
                        # Dil menüsünü aç
                        self.browser_utils.human_mouse_movement(option)
                        time.sleep(1)
                        
                        # İngilizce seçeneğini bul
                        english_options = self.driver.find_elements("xpath", 
                            "//*[contains(text(), 'English') or contains(text(), 'İngilizce') or contains(text(), 'Englisch')]")
                        
                        if english_options:
                            self.browser_utils.human_mouse_movement(english_options[0])
                            logger.info("Dil İngilizce olarak ayarlandı")
                            time.sleep(2)
                            return True
                except:
                    continue
            
            # Alternatif: localStorage ile dil ayarı
            self.driver.execute_script("localStorage.setItem('lang', 'en');")
            self.driver.execute_script("localStorage.setItem('ttcid', 'en');")
            logger.info("Dil localStorage üzerinden İngilizce olarak ayarlandı")
            return True
        except Exception as e:
            logger.error(f"Dil ayarlanırken sorun: {e}")
            return False
    
    def _accept_cookies(self):
        """Çerezleri kabul et"""
        try:
            cookie_button = self.wait.until(self._find_element(("xpath", "//button[contains(., 'Accept all')]")))
            self.browser_utils.human_mouse_movement(cookie_button)
            logger.info("Çerezler kabul edildi.")
            time.sleep(2)
        except:
            logger.warning("Çerez butonu bulunamadı, devam ediliyor.")
            pass
    
    def _select_birth_date(self):
        """Doğum tarihi seç"""
        logger.info("Doğum tarihi seçiliyor...")
        
        # Doğum tarihi menülerini bul
        date_dropdowns = self.wait.until(self._find_all_elements(("css selector", "div[role='combobox']")))
        
        # Ay seçimi
        self.browser_utils.human_mouse_movement(date_dropdowns[0])
        time.sleep(0.5)
        for _ in range(2):  # 2 kez aşağı = Mart
            date_dropdowns[0].send_keys(Keys.DOWN)
        date_dropdowns[0].send_keys(Keys.ENTER)
        logger.info("Ay seçildi.")
        time.sleep(0.5)

        # Gün seçimi
        self.browser_utils.human_mouse_movement(date_dropdowns[1])
        time.sleep(0.5)
        for _ in range(10):  # 10 kez aşağı = 11. gün
            date_dropdowns[1].send_keys(Keys.DOWN)
        date_dropdowns[1].send_keys(Keys.ENTER)
        logger.info("Gün seçildi.")
        time.sleep(0.5)

        # Yıl seçimi
        self.browser_utils.human_mouse_movement(date_dropdowns[2])
        time.sleep(0.5)
        for _ in range(25):  # 25 kez aşağı = ~1999
            date_dropdowns[2].send_keys(Keys.DOWN)
        date_dropdowns[2].send_keys(Keys.ENTER)
        logger.info("Yıl seçildi.")
        
        logger.info("Doğum tarihi seçildi.")
    
    def _solve_captcha(self) -> bool:
        """Captcha çöz"""
        try:
            # Captcha iframe'ini bul
            iframes = self.driver.find_elements("css selector", "iframe[title*='captcha'], iframe[title*='reCAPTCHA']")
            
            if iframes:
                self.driver.switch_to.frame(iframes[0])
                
                # Captcha resmini bul
                captcha_elements = self.driver.find_elements("css selector", "img[src*='captcha']")
                
                if captcha_elements:
                    # Resmin ekran görüntüsünü al
                    captcha_screenshot = captcha_elements[0].screenshot_as_png
                    
                    # Captcha çözücüyü kullan
                    result = self.captcha_solver.solve_captcha(captcha_screenshot)
                    
                    # Ana frame'e geri dön
                    self.driver.switch_to.default_content()
                    
                    # Çözümü uygula (eğer güvenilir ise)
                    if result.success and result.confidence > 0.7:
                        try:
                            # Captcha giriş alanını bul
                            captcha_input = self.driver.find_element("css selector", 
                                "input[name*='captcha'], input[id*='captcha'], input[placeholder*='captcha']")
                            
                            # Modelin ürettiği metni gir
                            self.browser_utils.human_typing(captcha_input, result.result)
                            logger.info("Captcha çözüldü ve girildi")
                            return True
                        except:
                            logger.warning("Captcha giriş alanı bulunamadı")
                    else:
                        logger.warning("Model düşük güvenle çözüm üretti")
                else:
                    logger.warning("Captcha resmi bulunamadı")
            else:
                logger.warning("Captcha iframe'i bulunamadı")
            
            # Ana frame'e dön
            try:
                self.driver.switch_to.default_content()
            except:
                pass
            
            return False
            
        except Exception as e:
            logger.error(f"Captcha çözücü hatası: {e}")
            try:
                self.driver.switch_to.default_content()
            except:
                pass
            return False
    
    def _create_username_and_save(self, password: str) -> bool:
        """Kullanıcı adı oluştur ve hesabı kaydet"""
        try:
            self.wait.until(lambda d: "username" in d.current_url)
            username = self.utils.generate_username(self.turkish_names)
            username_field = self.wait.until(self._find_element(("css selector", "input[name='username']")))
            self.browser_utils.human_typing(username_field, username)
            
            self.browser_utils.simulate_cognitive_delay(2)
            
            # Kayıt ol butonuna tıkla
            signup_button = self.wait.until(self._find_element(("xpath", "//button[contains(., 'Sign up')]")))
            self.browser_utils.human_mouse_movement(signup_button)
            
            logger.info(f"BAŞARILI: Hesap oluşturuldu: {username} | Şifre: {password}")
            
            # Zombi modunu aktif et
            self._activate_zombie_mode()

            # Hesap bilgilerini kaydet
            with open("created_accounts.txt", "a") as f:
                f.write(f"{username}:{password}:{self.email_utils.email_address}\n")

            return True
        except Exception as e:
            logger.error(f"Kullanıcı adı oluşturulurken hata: {e}")
            return False
    
    def _activate_zombie_mode(self):
        """Zombi modunu aktif et"""
        logger.info("Zombi Modu Aktif: Profil geçmişi oluşturuluyor...")
        influencers = ["charlidamelio", "khaby.lame", "bellapoarch", "mrbeast"]
        try:
            self.driver.get(f"https://www.tiktok.com/@{random.choice(influencers)}")
            self.browser_utils.simulate_cognitive_delay(3)
            
            for _ in range(random.randint(4, 7)):
                scroll_amount = random.randint(400, 800)
                self.driver.execute_script(f"window.scrollBy(0, {scroll_amount})")
                self.browser_utils.simulate_cognitive_delay(1.5)
                
                if random.random() > 0.6:
                    try:
                        like_btn = self.wait.until(self._find_element(("css selector", "[data-e2e='like-icon']")))
                        like_btn.click()
                        logger.info("Video beğenildi.")
                        self.browser_utils.simulate_cognitive_delay(1)
                    except:
                        pass  # Beğen butonu bulunamazsa devam et
        except Exception as e:
            logger.error(f"Zombi Modu sırasında hata: {e}")
    
    def _find_element(self, locator):
        """Element bulma yardımcısı"""
        from selenium.webdriver.common.by import By
        by, value = locator
        return lambda driver: driver.find_element(by, value)
    
    def _find_all_elements(self, locator):
        """Tüm elementleri bulma yardımcısı"""
        from selenium.webdriver.common.by import By
        by, value = locator
        return lambda driver: driver.find_elements(by, value)
