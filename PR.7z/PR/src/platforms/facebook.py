# src/platforms/facebook.py
import os
import time
import random
import json
import logging
from typing import Dict, List, Optional, Tuple, Union

from ..core.browser_utils import BrowserUtils
from ..core.email_utils import EmailUtils
from ..core.utils import Utils
from ..core.captcha_solver import AdvancedHybridCaptchaSolver, CaptchaResult

logger = logging.getLogger(__name__)

class FacebookPlatform:
    """Facebook platformu için otomasyon sınıfı"""
    
    def __init__(self, config_path: Optional[str] = None):
        self.config = self._load_config(config_path)
        self.browser_utils = BrowserUtils(config_path)
        self.email_utils = EmailUtils(config_path)
        self.utils = Utils()
        self.captcha_solver = AdvancedHybridCaptchaSolver(config_path)
        
        # İsimleri JSON dosyasından yükle
        self.names_data = self._load_names()
        
        # Proxy ve tarayıcı ayarları
        self.driver = None
        self.wait = None
        self.current_proxy = None
        
    def _load_config(self, config_path: Optional[str]) -> Dict:
        """Konfigürasyon dosyasını yükle"""
        default_config = {
            "browser": {
                "geckodriver_path": "/usr/local/bin/geckodriver",
                "headless": True,
                "window_size": [1920, 1080]
            },
            "email": {
                "service": "fake-email",
                "domain": "example.com",
                "max_wait_time": 300,
                "check_interval": 15
            },
            "captcha": {
                "model_path": "data/models/best_captcha_acc.keras",
                "confidence_threshold": 0.7
            }
        }
        
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    user_config = json.load(f)
                    # Merge configs
                    for key, value in user_config.items():
                        if key in default_config and isinstance(value, dict):
                            default_config[key].update(value)
                        else:
                            default_config[key] = value
            except Exception as e:
                logger.error(f"Konfigürasyon dosyası okunamadı: {e}")
        
        return default_config
    
    def _load_names(self) -> Dict:
        """İsimleri JSON dosyasından yükle"""
        try:
            with open("data/turkish_names.json", 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            logger.warning("'turkish_names.json' bulunamadı. Varsayılan isimler kullanılıyor.")
            return {
                "names": ["Ahmet", "Mehmet", "Mustafa"],
                "surnames": ["Yılmaz", "Kaya", "Demir"],
                "locations": ["İstanbul", "Ankara", "İzmir"]
            }
        except json.JSONDecodeError:
            logger.warning("'turkish_names.json' dosyası bozuk. Varsayılan isimler kullanılıyor.")
            return {
                "names": ["Ahmet", "Mehmet", "Mustafa"],
                "surnames": ["Yılmaz", "Kaya", "Demir"],
                "locations": ["İstanbul", "Ankara", "İzmir"]
            }
    
    def create_account(self) -> bool:
        """Facebook hesabı oluştur"""
        try:
            # Adım 1: Proxy döndür
            if not self.browser_utils.rotate_proxy("data/proxies.txt"):
                return False

            # Adım 2: Tarayıcıyı başlat
            self.driver = self.browser_utils.start_browser(self.current_proxy)
            self.wait = self.browser_utils.wait

            # Adım 3: E-posta oluştur
            if not self.email_utils.create_email():
                return False

            # Adım 4: Facebook'a git
            self.driver.get("https://www.facebook.com/")
            time.sleep(2)
            
            # Çerezleri kabul et
            self._accept_cookies()
            
            # Adım 5: Yeni hesap oluştur butonuna tıkla
            self._click_create_account()
            
            # Adım 6: Kayıt formunu doldur
            self._fill_signup_form()
            
            # Adım 7: Şifre oluştur ve gir
            password = self.utils.generate_password(
                length=12, 
                use_uppercase=True, 
                use_lowercase=True, 
                use_numbers=True, 
                use_special=True
            )
            logger.info(f"Oluşturulan Şifre: {password}")
            
            self._enter_password(password)
            
            # Adım 8: Captcha'yı çöz
            logger.info("Captcha çözülüyor...")
            captcha_solved = self._solve_captcha()
            
            if captcha_solved:
                logger.info("Captcha başarıyla çözüldü!")
            else:
                logger.warning("Captcha çözülemedi, 10 saniye manuel çözüm süresi...")
                time.sleep(10)
            
            # Adım 9: Kaydol butonuna tıkla
            self._click_signup_button()
            
            # Adım 10: Doğrulama kodunu e-postadan al
            verification_code = self.email_utils.get_verification_code()
            if not verification_code:
                logger.error("Doğrulama kodu alınamadı!")
                return False
            
            # Adım 11: Kod giriş alanını doldur
            self._enter_verification_code(verification_code)
            
            logger.info("Hesap oluşturma adımı tamamlandı.")
            
            # Adım 12: Hesap bilgilerini kaydet
            return self._save_account_info(password)
            
        except Exception as e:
            logger.error(f"Hesap oluşturulurken hata: {e}")
            if self.driver:
                error_filename = f"error_{int(time.time())}.png"
                self.browser_utils.take_screenshot(error_filename)
                logger.info(f"Hata ekran görüntüsü kaydedildi: {error_filename}")
            return False
        finally:
            if self.driver:
                self.driver.quit()
                self.driver = None
                self.wait = None
            logger.info("Oturum sonlandırıldı.")
    
    def _accept_cookies(self):
        """Çerezleri kabul et"""
        try:
            cookie_button = self.wait.until(self._find_element(("xpath", "//button[contains(text(), 'Accept All')]")))
            self.browser_utils.human_mouse_movement(cookie_button)
            logger.info("Çerezler kabul edildi.")
            time.sleep(2)
        except:
            logger.warning("Çerez butonu bulunamadı, devam ediliyor.")
            pass
    
    def _click_create_account(self):
        """Yeni hesap oluştur butonuna tıkla"""
        try:
            create_button = self.wait.until(self._find_element(("xpath", "//a[contains(text(), 'Create New Account')]")))
            self.browser_utils.human_mouse_movement(create_button)
            logger.info("Yeni hesap oluştur butonuna tıklandı.")
            time.sleep(2)
        except:
            logger.warning("Yeni hesap oluştur butonu bulunamadı, devam ediliyor.")
            pass
    
    def _fill_signup_form(self):
        """Kayıt formunu doldur"""
        try:
            # Adı gir
            first_name = random.choice(self.names_data["names"])
            first_name_field = self.wait.until(self._find_element(("css selector", "input[name='firstname']")))
            self.browser_utils.human_typing(first_name_field, first_name)
            logger.info(f"Ad girildi: {first_name}")
            time.sleep(1)
            
            # Soyadı gir
            last_name = random.choice(self.names_data["surnames"])
            last_name_field = self.wait.until(self._find_element(("css selector", "input[name='lastname']")))
            self.browser_utils.human_typing(last_name_field, last_name)
            logger.info(f"Soyadı girildi: {last_name}")
            time.sleep(1)
            
            # E-posta gir
            email_field = self.wait.until(self._find_element(("css selector", "input[name='reg_email__']")))
            self.browser_utils.human_typing(email_field, self.email_utils.email_address)
            logger.info(f"E-posta girildi: {self.email_utils.email_address}")
            time.sleep(1)
            
            # E-postayı tekrar gir
            confirm_email_field = self.wait.until(self._find_element(("css selector", "input[name='reg_email_confirmation__']")))
            self.browser_utils.human_typing(confirm_email_field, self.email_utils.email_address)
            logger.info("E-posta tekrar girildi.")
            time.sleep(1)
            
            # Doğum tarihini gir
            self._enter_birth_date()
            
        except Exception as e:
            logger.error(f"Kayıt formu doldurulurken hata: {e}")
    
    def _enter_birth_date(self):
        """Doğum tarihini gir"""
        try:
            # Ay seç
            month_dropdown = self.wait.until(self._find_element(("css selector", "select[name='birthday_month']")))
            self.browser_utils.human_mouse_movement(month_dropdown)
            time.sleep(0.5)
            
            # Rastgele bir ay seç
            for _ in range(random.randint(1, 12)):
                month_dropdown.send_keys(Keys.DOWN)
            month_dropdown.send_keys(Keys.ENTER)
            logger.info("Ay seçildi.")
            time.sleep(0.5)
            
            # Gün seç
            day_dropdown = self.wait.until(self._find_element(("css selector", "select[name='birthday_day']")))
            self.browser_utils.human_mouse_movement(day_dropdown)
            time.sleep(0.5)
            
            # Rastgele bir gün seç
            for _ in range(random.randint(1, 28)):
                day_dropdown.send_keys(Keys.DOWN)
            day_dropdown.send_keys(Keys.ENTER)
            logger.info("Gün seçildi.")
            time.sleep(0.5)
            
            # Yıl seç
            year_dropdown = self.wait.until(self._find_element(("css selector", "select[name='birthday_year']")))
            self.browser_utils.human_mouse_movement(year_dropdown)
            time.sleep(0.5)
            
            # 1990-2000 arası bir yıl seç
            for _ in range(random.randint(15, 25)):
                year_dropdown.send_keys(Keys.DOWN)
            year_dropdown.send_keys(Keys.ENTER)
            logger.info("Yıl seçildi.")
            time.sleep(0.5)
            
            # Cinsiyet seç
            gender_radio = self.wait.until(self._find_element(("css selector", "input[name='sex'][value='2']")))  # 2 = Female
            self.browser_utils.human_mouse_movement(gender_radio)
            logger.info("Cinsiyet seçildi.")
            time.sleep(1)
            
        except Exception as e:
            logger.error(f"Doğum tarihi girilirken hata: {e}")
    
    def _enter_password(self, password: str):
        """Şifre gir"""
        try:
            password_field = self.wait.until(self._find_element(("css selector", "input[name='reg_passwd__']")))
            self.browser_utils.human_typing(password_field, password)
            logger.info("Şifre girildi.")
            time.sleep(1)
        except Exception as e:
            logger.error(f"Şifre girilirken hata: {e}")
    
    def _solve_captcha(self) -> bool:
        """Captcha çöz"""
        try:
            # Captcha iframe'ini bul
            iframes = self.driver.find_elements("css selector", "iframe[title*='captcha'], iframe[title*='reCAPTCHA']")
            
            if iframes:
                self.driver.switch_to.frame(iframes[0])
                
                # Captcha resmini bul
                captcha_elements = self.driver.find_elements("css selector", "img[src*='captcha']")
                
                if captcha_elements:
                    # Resmin ekran görüntüsünü al
                    captcha_screenshot = captcha_elements[0].screenshot_as_png
                    
                    # Captcha çözücüyü kullan
                    result = self.captcha_solver.solve_captcha(captcha_screenshot)
                    
                    # Ana frame'e geri dön
                    self.driver.switch_to.default_content()
                    
                    # Çözümü uygula (eğer güvenilir ise)
                    if result.success and result.confidence > 0.7:
                        try:
                            # Captcha giriş alanını bul
                            captcha_input = self.driver.find_element("css selector", 
                                "input[name*='captcha'], input[id*='captcha'], input[placeholder*='captcha']")
                            
                            # Modelin ürettiği metni gir
                            self.browser_utils.human_typing(captcha_input, result.result)
                            logger.info("Captcha çözüldü ve girildi")
                            return True
                        except:
                            logger.warning("Captcha giriş alanı bulunamadı")
                    else:
                        logger.warning("Model düşük güvenle çözüm üretti")
                else:
                    logger.warning("Captcha resmi bulunamadı")
            else:
                logger.warning("Captcha iframe'i bulunamadı")
            
            # Ana frame'e dön
            try:
                self.driver.switch_to.default_content()
            except:
                pass
            
            return False
            
        except Exception as e:
            logger.error(f"Captcha çözücü hatası: {e}")
            try:
                self.driver.switch_to.default_content()
            except:
                pass
            return False
    
    def _click_signup_button(self):
        """Kaydol butonuna tıkla"""
        try:
            signup_button = self.wait.until(self._find_element(("css selector", "button[name='websubmit']")))
            self.browser_utils.human_mouse_movement(signup_button)
            logger.info("Kaydol butonuna tıklandı.")
            time.sleep(2)
        except Exception as e:
            logger.error(f"Kaydol butonuna tıklanırken hata: {e}")
    
    def _enter_verification_code(self, code: str):
        """Doğrulama kodunu gir"""
        try:
            code_field = self.wait.until(self._find_element(("css selector", "input[id='approvals_code']")))
            self.browser_utils.human_typing(code_field, code)
            logger.info("Doğrulama kodu girildi.")
            time.sleep(1)
            
            # Onayla butonuna tıkla
            confirm_button = self.wait.until(self._find_element(("css selector", "button[id='confirm']")))
            self.browser_utils.human_mouse_movement(confirm_button)
            logger.info("Onayla butonuna tıklandı.")
            time.sleep(2)
        except Exception as e:
            logger.error(f"Doğrulama kodu girilirken hata: {e}")
    
    def _save_account_info(self, password: str) -> bool:
        """Hesap bilgilerini kaydet"""
        try:
            # Kullanıcı adını al
            username = self.email_utils.email_address.split('@')[0]
            
            logger.info(f"BAŞARILI: Hesap oluşturuldu: {username} | Şifre: {password}")
            
            # Hesap bilgilerini kaydet
            with open("created_accounts.txt", "a") as f:
                f.write(f"facebook:{username}:{password}:{self.email_utils.email_address}\n")

            return True
        except Exception as e:
            logger.error(f"Hesap bilgileri kaydedilirken hata: {e}")
            return False
    
    def _find_element(self, locator):
        """Element bulma yardımcısı"""
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.common.exceptions import TimeoutException
        
        by, value = locator
        try:
            return EC.presence_of_element_located((by, value))
        except TimeoutException:
            return EC.visibility_of_element_located((by, value))
