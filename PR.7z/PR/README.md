# Hibrit CAPTCHA Çözüm Sistemi

Bu proje, farklı türlerdeki CAPTCHA'ları çözmek için tasarlanmış gelişmiş bir hibrit sistemdir. OCR (Optik Karakter Tanıma) ve nesne algılama (YOLO) teknolojilerini birleştirerek yüksek başarı oranı sağlar.

## Özellikler

- **Hibrit Çözüm Sistemi**: Farklı CAPTCHA türlerini otomatik olarak tanır ve en uygun çözüm yöntemini uygular
- **OCR Tabanlı Çözüm**: Metin tabanlı CAPTCHA'lar için CRNN modeli kullanır
- **Nesne Algılama**: Görüntü seçme tabanlı CAPTCHA'lar için YOLO modeli kullanır
- **Sürekli Öğrenme**: Kullanıcı geri bildirimleriyle modelleri sürekli iyileştirir
- **Performans İzleme**: Sistem performansını gerçek zamanlı olarak izler
- **Çoklu Platform Desteği**: TikTok, Instagram, Twitter, Facebook gibi platformlar için otomatik hesap oluşturma
- **API Desteği**: RESTful API ile dış uygulamalara hizmet verir
- **CLI Arayüzü**: Komut satırından tüm sistemi yönetme imkanı
- **Docker Desteği**: Kolay dağıtım için Docker imajı

## Gereksinimler

- Python 3.8+
- Firefox (Selenium otomasyonu için)
- CUDA (GPU destekli eğitim için - opsiyonel)

## Kurulum

### Geliştirme Ortamı

1. Depoyu klonlayın:
```bash
git clone https://github.com/yourusername/hybrid-captcha-solver.git
cd hybrid-captcha-solver
```

2. Sanal ortam oluşturun:
```bash
python -m venv venv
source venv/bin/activate  # Windows için: venv\Scripts\activate
```

3. Bağımlılıkları yükleyin:
```bash
pip install -r requirements.txt
```

4. Paketi kurun:
```bash
pip install -e .
```

### Docker ile Kurulum

1. Docker imajını oluşturun:
```bash
docker build -t hybrid-captcha-solver .
```

2. Konteyneri çalıştırın:
```bash
docker run -p 8000:8000 hybrid-captcha-solver
```

## Kullanım

### CLI Arayüzü

Sistemi komut satırından yönetmek için:

```bash
# Interaktif kabuğu başlat
captcha-solver

# Doğrudan komut çalıştır
captcha-solver --command "solve test_captcha.png"

# Farklı modlarda çalıştır
captcha-solver --mode api
captcha-solver --mode batch
```

#### Interaktif Kabuk Komutları

- `solve <dosya_yolu>`: Tekil CAPTCHA çözümü
- `batch <dizin_yolu>`: Batch CAPTCHA çözümü
- `status`: Sistem durumunu göster
- `train [captcha|yolo]`: Model eğitimi
- `platform <platform> <operation>`: Platform işlemleri
- `api [start|stop]`: API sunucusunu başlat/durdur
- `config [show|edit]`: Yapılandırmayı göster/düzenle
- `test [all|solvers|platforms]`: Testleri çalıştır
- `exit` veya `quit`: Sistemden çık

### API Kullanımı

API sunucusunu başlattıktan sonra:

```python
import requests
import base64

# Görüntüyü base64'e çevir
with open("captcha.png", "rb") as f:
    image_data = base64.b64encode(f.read()).decode()

# API isteği
response = requests.post(
    "http://localhost:8000/solve",
    json={
        "image_data": image_data,
        "use_cache": True
    }
)

if response.status_code == 200:
    data = response.json()
    print(f"Sonuç: {data['result']}")
    print(f"Başarı: {data['success']}")
```

### Python Kütüphanesi Olarak Kullanım

```python
from src.core.captcha_solver import AdvancedHybridCaptchaSolver

# Çözücüyü başlat
solver = AdvancedHybridCaptchaSolver()

# CAPTCHA çözümü yap
result = solver.solve_captcha("captcha.png")

print(f"Sonuç: {result.result}")
print(f"Başarı: {result.success}")
```

### Platform Otomasyonu

```python
from src.platforms.tiktok import TikTokPlatform
from src.platforms.instagram import InstagramPlatform

# TikTok hesabı oluştur
tiktok = TikTokPlatform()
success = tiktok.create_account()

# Instagram hesabı oluştur
instagram = InstagramPlatform()
success = instagram.create_account()
```

## Proje Yapısı

```
project_root/
├── cli.py                # Tek giriş noktası: CLI shell'i buradan çalışır
├── setup.py              # Paketleme için (pip install -e . ile yerel kurulum)
├── requirements.txt      # Tüm dependencies: selenium, tensorflow, torch, fastapi, redis vb.
├── config.json           # Varsayılan config (redis, security, solvers)
├── Dockerfile            # Docker için (opsiyonel, ama üretim için şart)
├── README.md             # Kullanım kılavuzu
├── data/                 # Veri dosyaları
│   ├── turkish_names.json
│   ├── fingerprints.json
│   ├── proxies.txt
│   └── models/          # Eğitilmiş modeller
│       ├── best_captcha_acc.keras  # CRNN modeli
│       └── yolo_model.pt           # YOLO modeli
├── src/                  # Kaynak kodlar (modülerlik için)
│   ├── core/             # Ortak çekirdek modüller (her platformun kullandığı)
│   │   ├── __init__.py
│   │   ├── browser_utils.py     # Selenium, proxy, fingerprint, human simulation
│   │   ├── captcha_solver.py    # Hibrit solver (CRNN + YOLO), type detection, fallback
│   │   ├── email_utils.py       # Fake email generation and verification
│   │   ├── utils.py             # Genel yardımcılar (delays, logging, error handling)
│   │   └── monitoring.py        # Performance metrics, alerts, continuous learning
│   ├── platforms/         # Platformlara özel modüller (ayrı dosyalar, kolay ekleme)
│   │   ├── __init__.py
│   │   ├── tiktok.py            # Mevcut TikTok script'i buraya taşınır
│   │   ├── instagram.py         # Yeni: Instagram hesap oluşturma
│   │   ├── twitter.py           # Yeni: X/Twitter için
│   │   ├── facebook.py          # Yeni: FB için
│   │   └── generic.py           # Genel platform şablonu
│   ├── api/               # FastAPI kısmı (eğer CLI'den ayrı çalışsın istiyorsan)
│   │   ├── __init__.py
│   │   └── server.py            # production_captcha_solver.py buraya
│   └── training/          # Eğitim script'leri
│       ├── __init__.py
│       ├── captcha_trainer.py   # captcha-solver.py (CRNN eğitimi)
│       └── yolo_trainer.py      # YOLO fine-tuning
├── tests/                # Testler
│   ├── __init__.py
│   └── test_solvers.py          # test_and_usage_examples.py buraya
└── docs/                 # Dokümanlar
    └── readme.txt              # Mevcut planlama doc'u
```

## Yapılandırma

Sistem `config.json` dosyası üzerinden yapılandırılır. Varsayılan yapılandırma:

```json
{
  "redis": {
    "host": "localhost",
    "port": 6379,
    "db": 0,
    "password": null
  },
  "security": {
    "jwt_secret": "your-jwt-secret-key",
    "encryption_key": "your-encryption-key",
    "rate_limits": {
      "requests_per_minute": 60,
      "requests_per_hour": 1000
    }
  },
  "solvers": {
    "ocr": {
      "enabled": true,
      "model_path": "data/models/best_captcha_acc.keras"
    },
    "yolo": {
      "enabled": true,
      "model_path": "data/models/yolo_model.pt"
    }
  },
  "browser": {
    "geckodriver_path": "/usr/local/bin/geckodriver",
    "headless": true,
    "window_size": [1920, 1080]
  },
  "email": {
    "service": "fake-email",
    "domain": "example.com"
  },
  "monitoring": {
    "enabled": true,
    "metrics_interval": 60,
    "health_check_interval": 300
  },
  "training": {
    "batch_size": 16,
    "epochs": 100,
    "learning_rate": 0.001,
    "validation_split": 0.2
  }
}
```

## Model Eğitimi

### CRNN Modeli Eğitimi

```bash
# CLI üzerinden
captcha-solver --command "train captcha"

# Doğrudan çalıştır
python src/training/captcha_trainer.py
```

### YOLO Modeli Eğitimi

```bash
# CLI üzerinden
captcha-solver --command "train yolo"

# Doğrudan çalıştır
python src/training/yolo_trainer.py
```

## Testler

Testleri çalıştırmak için:

```bash
# CLI üzerinden
captcha-solver --command "test all"

# pytest ile
pytest tests/
```

## Performans İzleme

Sistem çeşitli metriklerle performans izleme sağlar:

- **Başarı Oranı**: Çözülen CAPTCHA'ların başarı yüzdesi
- **İşlem Süresi**: Ortalama çözüm süresi
- **Cache Hit Rate**: Cache kullanım oranı
- **Solver Performansı**: Her bir çözücünün performansı
- **H

(Yazacağım şeyi unuttuğum için burda bırakıyorum)
